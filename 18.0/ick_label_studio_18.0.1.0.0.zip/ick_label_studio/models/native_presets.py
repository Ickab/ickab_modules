import json

from odoo import api, fields, models


def _element(key, kind, path, x, y, width, height, **options):
    return dict({"id": key, "type": kind, "source": "field", "field_path": path,
                 "x_mm": x, "y_mm": y, "w_mm": width, "h_mm": height,
                 "font_mm": 2.2, "max_lines": 1}, **options)


def _product_design(width, height, price=False):
    small = height <= 20
    elements = [
        _element("name", "text", "display_name", 1, 1, width - 2, 4 if small else 6),
        _element("reference", "text", "default_code", 1, 5 if small else 8, width - 2, 3),
        _element("barcode", "barcode", "barcode", 2, 10 if small else 14, width - 4, 7 if small else height - 17,
                 barcode_type="code128", human_readable=True),
    ]
    if price:
        elements[1]["w_mm"] = (width - 2) / 2
        elements.append(_element("price", "text", "ick_studio_price_text", width / 2, 5 if small else 8,
                                 width / 2 - 1, 4, align="R", font_mm=2.5))
    return {"version": 2, "elements": elements}


class LabelTemplate(models.Model):
    _inherit = "ickab.label.template"

    ick_native_source = fields.Char(string="Plantilla Odoo de origen", readonly=True, copy=False)

    @api.model
    def _ick_native_preset_specs(self):
        """Editable label-sized counterparts of installed Odoo label formats.

        Grid labels retain each label's measured size. This does not silently
        turn the individual-label renderer into an A4 imposition renderer.
        """
        result = []
        products = [
            ("dymo", "Dymo", 57, 32, False, "product.report_simple_label_dymo"),
            ("2x7_price", "2 × 7 con precio", 97, 37.1, True, "product.report_simple_label2x7"),
            ("4x7_price", "4 × 7 con precio", 47, 37.1, True, "product.report_simple_label4x7"),
            ("4x12", "4 × 12", 43, 19, False, "product.report_simple_label4x12_no_price"),
            ("4x12_price", "4 × 12 con precio", 43, 19, True, "product.report_simple_label4x12"),
            ("zpl", "ZPL sin precio", 76, 50, False, "stock.label_product_product_view"),
            ("zpl_price", "ZPL con precio", 76, 50, True, "stock.label_product_product_view"),
        ]
        for model in ("product.template", "product.product"):
            for key, title, width, height, price, origin in products:
                result.append({"key": "product_%s_%s" % ("template" if model == "product.template" else "variant", key),
                    "name": "Odoo · %s · %s" % (title, "Producto" if model == "product.template" else "Variante"),
                    "model": model, "width": width, "height": height, "origin": origin,
                    "design": _product_design(width, height, price),
                    "notes": "Prediseño editable basado en Odoo. Tamaño de una etiqueta: %s × %s mm. "
                             "La impresión de Studio es individual; para la hoja A4 completa conserve el formato nativo del asistente. "
                             "El precio usa la lista seleccionada en el asistente, o el precio de venta si no se indica lista." % (width, height)})
        for key, title, width, height, origin in [
            ("lot_pdf", "Lote / serie · 43 × 19 mm", 43, 19, "stock.report_lot_label"),
            ("lot_zpl", "Lote / serie · ZPL", 76, 50, "stock.label_lot_template_view"),
        ]:
            small = height <= 20
            result.append({"key": key, "name": "Odoo · " + title, "model": "stock.lot", "width": width, "height": height,
                "origin": origin, "design": {"version": 2, "elements": [
                    _element("product", "text", "product_id.display_name", 1, 1, width - 2, 4),
                    _element("lot", "text", "name", 1, 5, width - 2, 3),
                    _element("barcode", "barcode", "name", 2, 9 if small else 14, width - 4, 8 if small else height - 17,
                             barcode_type="code128", human_readable=True)]},
                "notes": "Prediseño editable de lote/serie basado en la etiqueta nativa. Código Code128 de la identidad del lote; no construye GS1/DataMatrix."})
        for key, title, model, origin, path in [
            ("package", "Paquete", "stock.quant.package", "stock.label_package_template_view", "name"),
            ("packaging", "Embalaje de producto", "product.packaging", "stock.label_product_packaging_view", "barcode"),
            ("picking_type", "Tipo de operación", "stock.picking.type", "stock.label_picking_type_view", "barcode"),
        ]:
            result.append({"key": key, "name": "Odoo · " + title, "model": model, "origin": origin, "width": 76, "height": 50,
                "design": {"version": 2, "elements": [_element("name", "text", "display_name", 2, 2, 72, 8),
                    _element("barcode", "barcode", path, 3, 14, 70, 30, barcode_type="code128", human_readable=True)]},
                "notes": "Versión editable para etiqueta individual basada en el contenido de la plantilla nativa de Odoo."})
        for key, title, origin, width, height in [
            ("finished_pdf", "Terminado · 43 × 19 mm", "mrp.label_production_view_pdf", 43, 19),
            ("finished_zpl", "Terminado · ZPL", "mrp.label_production_view", 76, 50),
            ("transfer_pdf", "Transferencia · PDF", "stock.label_transfer_template_view_pdf", 76, 50),
            ("transfer_zpl", "Transferencia · ZPL", "stock.label_transfer_template_view_zpl", 76, 50),
        ]:
            for tracked in (True, False):
                path = "lot_id.name" if tracked else "product_id.barcode"
                small = height <= 20
                result.append({"key": key + ("_lot" if tracked else "_product"),
                    "name": "Odoo · %s · %s" % (title, "Con lote" if tracked else "Sin seguimiento"),
                    "model": "stock.move.line", "origin": origin, "width": width, "height": height,
                    "design": {"version": 2, "elements": [
                        _element("product", "text", "product_id.display_name", 1, 1, width - 2, 4),
                        _element("quantity", "text", "quantity", 1, 5, width / 2 - 1, 3),
                        _element("unit", "text", "product_uom_id.name", width / 2, 5, width / 2 - 1, 3),
                        _element("barcode", "barcode", path, 2, 9 if small else 14, width - 4, 8 if small else height - 17,
                                 barcode_type="code128", human_readable=True)]},
                    "notes": "Etiqueta individual basada en la línea real de movimiento. Seleccione la versión con lote o sin seguimiento según el producto. La cantidad corresponde a esta línea; las copias se eligen al imprimir."})
        result.append({"key": "reception", "name": "Odoo · Informe de recepción · Producto", "model": "stock.move",
            "origin": "stock.report_reception_report_label", "width": 76, "height": 50,
            "design": {"version": 2, "elements": [
                _element("product", "text", "product_id.display_name", 2, 2, 72, 7),
                _element("quantity", "text", "quantity", 2, 10, 34, 5),
                _element("unit", "text", "product_uom.name", 38, 10, 34, 5),
                _element("barcode", "barcode", "product_id.barcode", 3, 18, 70, 27, barcode_type="code128", human_readable=True)]},
            "notes": "Etiqueta individual editable de producto y cantidad de movimiento. No incluye la asignación de demanda ni la imposición de páginas del informe nativo de recepción."})
        return result

    @api.model
    def _ick_load_native_presets(self):
        ModelData = self.env["ir.model.data"]
        for spec in self._ick_native_preset_specs():
            if spec["model"] not in self.env or not self.env.ref(spec["origin"], raise_if_not_found=False):
                continue
            model = self.env["ir.model"]._get(spec["model"])
            name = "ick_native_" + spec["key"]
            binding = ModelData.search([("module", "=", "ick_label_studio"), ("name", "=", name)], limit=1)
            if binding and binding.model == self._name and self.browse(binding.res_id).exists():
                continue
            record = self.create({"name": spec["name"], "model_id": model.id, "company_id": False,
                "width_mm": spec["width"], "height_mm": spec["height"], "safe_margin_mm": 0.5,
                "document_mode": "studio", "ick_native_source": spec["origin"],
                "notes": spec["notes"], "design_json": json.dumps(spec["design"], ensure_ascii=False)})
            values = {"module": "ick_label_studio", "name": name, "model": self._name, "res_id": record.id, "noupdate": True}
            if binding:
                binding.write(values)
            else:
                ModelData.create(values)
        return True
