from datetime import date, datetime

from babel.dates import format_date, format_datetime, parse_pattern

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools.misc import get_lang


class LabelDateFormat(models.Model):
    _name = "ickab.label.date.format"
    _description = "Formato de fecha para etiquetas"
    _order = "sequence, name, id"

    name = fields.Char(string="Nombre", required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    format_pattern = fields.Char(string="Patrón", required=True,
        help="Patrón de fecha: yyMM produce año y mes (2706); dd/MM/yyyy produce 08/06/2027. "
             "MM es mes; mm es minuto. El nombre puede ser AAmm u otro identificador de uso interno.")
    applies_to = fields.Selection([("both", "Fecha y fecha/hora"), ("date", "Fecha"),
                                  ("datetime", "Fecha/hora")], string="Aplicable a", default="both", required=True)
    example = fields.Char(string="Ejemplo", compute="_compute_example")

    @api.constrains("format_pattern", "applies_to")
    def _check_pattern(self):
        for record in self:
            pattern = record.format_pattern or ""
            if not pattern.strip() or len(pattern) > 80:
                raise ValidationError(_("El patrón debe contener entre 1 y 80 caracteres."))
            try:
                parse_pattern(pattern)
                if record.applies_to in ("date", "both"):
                    format_date(date(2027, 6, 8), format=pattern, locale="es_MX")
                if record.applies_to in ("datetime", "both"):
                    format_datetime(datetime(2027, 6, 8, 13, 4, 5), format=pattern, locale="es_MX")
            except (ValueError, KeyError, AttributeError, TypeError) as exc:
                raise ValidationError(_("El patrón no es válido para el tipo de fecha seleccionado.")) from exc

    @api.depends("format_pattern", "applies_to")
    @api.depends_context("lang", "tz")
    def _compute_example(self):
        for record in self:
            try:
                record.example = record._format_value(
                    date(2027, 6, 8) if record.applies_to == "date" else datetime(2027, 6, 8, 13, 4, 5),
                    "date" if record.applies_to == "date" else "datetime", record)
            except (UserError, ValueError, KeyError, AttributeError, TypeError):
                record.example = ""

    def _format_value(self, value, field_type, context_record):
        self.ensure_one()
        self.check_access("read")
        if field_type not in ("date", "datetime") or self.applies_to not in ("both", field_type):
            raise UserError(_("El formato %(format)s no es compatible con este tipo de fecha.", format=self.name))
        if value is False or value is None:
            return ""
        locale = get_lang(context_record.env).code
        try:
            if field_type == "date":
                return format_date(fields.Date.to_date(value), format=self.format_pattern, locale=locale)
            local = fields.Datetime.context_timestamp(context_record, fields.Datetime.to_datetime(value))
            return format_datetime(local, format=self.format_pattern, locale=locale)
        except (ValueError, KeyError, AttributeError, TypeError) as exc:
            raise UserError(_("No fue posible aplicar el formato de fecha %(format)s.", format=self.name)) from exc

    def unlink(self):
        raise UserError(_("Archive el formato de fecha para conservar los diseños que ya lo utilizan."))
