from odoo import api, fields, models
from odoo.tools.misc import format_amount


def _price_text(record):
    pricelist = record.env["product.pricelist"].browse(record.env.context.get("ick_label_pricelist_id")).exists()
    currency = pricelist.currency_id or record.currency_id
    if pricelist:
        pricelist.check_access("read")
        price = pricelist._get_product_price(record, 1, currency=currency)
    else:
        price = record.lst_price if record._name == "product.product" else record.list_price
    return format_amount(record.env, price, currency)


class ProductTemplate(models.Model):
    _inherit = "product.template"

    ick_studio_price_text = fields.Char(string="Precio para etiqueta", compute="_ick_compute_studio_price_text")

    @api.depends("list_price", "currency_id")
    @api.depends_context("ick_label_pricelist_id", "lang", "company")
    def _ick_compute_studio_price_text(self):
        for record in self:
            record.ick_studio_price_text = _price_text(record)


class ProductProduct(models.Model):
    _inherit = "product.product"

    ick_studio_price_text = fields.Char(string="Precio para etiqueta", compute="_ick_compute_studio_price_text")

    @api.depends("lst_price", "currency_id")
    @api.depends_context("ick_label_pricelist_id", "lang", "company")
    def _ick_compute_studio_price_text(self):
        for record in self:
            record.ick_studio_price_text = _price_text(record)
