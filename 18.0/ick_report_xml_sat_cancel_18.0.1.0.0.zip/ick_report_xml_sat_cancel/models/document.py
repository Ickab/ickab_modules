from odoo import fields, models, _
from odoo.exceptions import AccessError, UserError
from ..receipt import complete_registered_data, parse_receipt

CANCEL_STATES = ('invoice_cancel_requested', 'invoice_cancel', 'payment_cancel', 'ginvoice_cancel')


class Attachment(models.Model):
    _inherit = 'ir.attachment'

    ick_cancel_receipt_test = fields.Boolean(copy=False, readonly=True)


class Document(models.Model):
    _inherit = 'l10n_mx_edi.document'

    ick_cancel_receipt_available = fields.Boolean(compute='_compute_cancel_receipt_available')

    def _ick_check_receipt_access(self):
        self.ensure_one()
        self.check_access('read')
        moves = self.move_id | self.invoice_ids
        if not moves:
            raise AccessError(_('El documento no tiene un origen contable accesible.'))
        moves.check_access('read')
        if any(company.id not in self.env.companies.ids for company in moves.company_id):
            raise AccessError(_('El documento pertenece a otra compañía.'))

    def _ick_cancel_receipt_attachment(self):
        self.ensure_one()
        self._ick_check_receipt_access()
        if self.state not in CANCEL_STATES or not self.attachment_uuid or not self.attachment_id:
            return self.env['ir.attachment']
        # Native cancellation records deliberately reference the original CFDI.
        # The PAC receipt is attached to its sent document. Never replace it.
        sources = self.search([('attachment_id', '=', self.attachment_id.id),
                               ('attachment_uuid', '=', self.attachment_uuid)])
        sources = sources.filtered(lambda d: d.move_id == self.move_id and d.invoice_ids == self.invoice_ids)
        return self.env['ir.attachment'].search([
            ('res_model', '=', self._name), ('res_id', 'in', sources.ids),
            ('name', '=', 'CANCEL_%s.xml' % self.attachment_uuid),
        ], order='id desc', limit=1)

    def _compute_cancel_receipt_available(self):
        for document in self:
            try:
                document.ick_cancel_receipt_available = bool(document._ick_cancel_receipt_attachment())
            except AccessError:
                document.ick_cancel_receipt_available = False

    def _ick_cancel_receipt_values(self):
        self.ensure_one()
        attachment = self._ick_cancel_receipt_attachment()
        if not attachment:
            raise UserError(_('No existe un XML de acuse de cancelación para este documento.'))
        attachment.check_access('read')
        original = self._decode_cfdi_attachment(self.attachment_id.raw)
        if not original:
            raise UserError(_('No se puede verificar el comprobante original.'))
        company = (self.move_id | self.invoice_ids).company_id
        providers = original['cfdi_node'].xpath("//*[local-name()='TimbreFiscalDigital']/@RfcProvCertif")
        original_is_test = 'SPR190613I52' in providers
        try:
            receipt = parse_receipt(attachment.raw, self.attachment_uuid, original['supplier_rfc'],
                                    allow_test=attachment.ick_cancel_receipt_test or original_is_test
                                    or bool(company and company.root_id.l10n_mx_edi_pac_test_env))
        except ValueError as exc:
            raise UserError(str(exc)) from exc
        # A test stamp remains a test stamp after changing company settings.
        receipt['test'] = receipt['test'] or original_is_test or attachment.ick_cancel_receipt_test
        receipt = complete_registered_data(receipt, self.attachment_uuid, self.cancellation_reason,
                                           original.get('certificate_number'))
        process_label = dict(self._fields['state']._description_selection(self.env)).get(self.state)
        if self.state in ('invoice_cancel', 'payment_cancel', 'ginvoice_cancel'):
            process_label = 'Cancelación Simulada' if receipt['test'] else 'Cancelación registrada'
        elif self.state == 'invoice_cancel_requested':
            process_label = 'Solicitud de cancelación registrada'
        receipt.update({'attachment': attachment, 'document': self,
                        'reference': ', '.join((self.move_id | self.invoice_ids).mapped('name')),
                        'odoo_state': process_label,
                        'sat_state': dict(self._fields['sat_state']._description_selection(self.env)).get(self.sat_state),
                        'odoo_reason': dict(self._fields['cancellation_reason']._description_selection(self.env)).get(self.cancellation_reason),
                        'expected_uuid': self.attachment_uuid})
        return receipt

    def action_ick_print_cancel_receipt(self):
        self._ick_cancel_receipt_values()
        return self.env.ref('ick_report_xml_sat_cancel.action_cancel_receipt').report_action(self, config=False)

    def action_ick_download_cancel_receipt(self):
        values = self._ick_cancel_receipt_values()
        return {'type': 'ir.actions.act_url', 'url': '/web/content/%s?download=true' % values['attachment'].id,
                'target': 'self'}
