"""Preserve PAC receipts while leaving native cancellation orchestration intact.

Finkok's request/validation mirrors Odoo 18's adapter, adding Acuse storage.
Solución Factible uses its documented Cancelacion service, which returns the
SAT XML; its Timbrado.cancelar service used by core only returns status codes.
"""
import base64
import binascii
import logging

from cryptography.hazmat.primitives import serialization
from odoo import api, models, _
from odoo.tools.zeep import Client
from ..receipt import parse_receipt

_logger = logging.getLogger(__name__)


class Document(models.Model):
    _inherit = 'l10n_mx_edi.document'

    def _cancel_api(self, company, cancel_reason, on_failure, on_success):
        self.ensure_one()
        document = self.with_context(ick_cancel_source_document_id=self.id)
        return super(Document, document)._cancel_api(company, cancel_reason, on_failure, on_success)

    def _ick_store_pac_receipt(self, content, uuid, company):
        """Keep the exact XML bytes, never replace the original stamped CFDI."""
        source_id = self.env.context.get('ick_cancel_source_document_id')
        source = self.browse(source_id).exists() if source_id else self
        if not source or not content:
            return False
        source.ensure_one()
        source.check_access('write')
        if source.attachment_uuid.upper() != uuid.upper():
            return False
        try:
            raw = content.encode('utf-8') if isinstance(content, str) else content
            if not raw.lstrip(b'\xef\xbb\xbf \n\r\t').startswith(b'<'):
                raw = base64.b64decode(b''.join(raw.split()), validate=True)
            parse_receipt(raw, uuid, company.vat, allow_test=company.l10n_mx_edi_pac_test_env)
        except (ValueError, TypeError, binascii.Error):
            _logger.warning('Invalid or mismatched cancellation receipt for EDI document %s', source.id)
            return False
        attachments = self.env['ir.attachment']
        name = 'CANCEL_%s.xml' % uuid
        existing = attachments.search([('res_model', '=', source._name),
                                       ('res_id', '=', source.id), ('name', '=', name)])
        if not any(attachment.raw == raw for attachment in existing):
            attachments.create({'name': name, 'raw': raw, 'mimetype': 'application/xml',
                                'res_model': source._name, 'res_id': source.id,
                                'ick_cancel_receipt_test': company.l10n_mx_edi_pac_test_env})
        return True

    @api.model
    def _document_sw_call(self, url, headers, payload=None):
        result = super()._document_sw_call(url, headers, payload=payload)
        source_id = self.env.context.get('ick_cancel_source_document_id')
        data = result.get('data') or {}
        if source_id and result.get('status') == 'success' and data.get('acuse'):
            source = self.browse(source_id).exists()
            if source:
                company = (source.move_id | source.invoice_ids).company_id.root_id
                self._ick_store_pac_receipt(data['acuse'], source.attachment_uuid, company)
        return result

    @api.model
    def _finkok_cancel(self, cfdi_values, credentials, uuid, cancel_reason, cancel_uuid=None):
        company = cfdi_values['root_company']
        certificate = cfdi_values['certificate'].sudo()
        try:
            client = Client(credentials['cancel_url'], timeout=20)
            factory = client.type_factory('apps.services.soap.core.views')
            folio = factory.UUID()
            folio.UUID, folio.Motivo = uuid, cancel_reason
            if cancel_uuid:
                folio.FolioSustitucion = cancel_uuid
            response = client.service.cancel(
                factory.UUIDArray(folio), credentials['username'], credentials['password'], company.vat,
                base64.b64decode(certificate.pem_certificate),
                base64.b64decode(certificate.private_key_id.pem_key),
            )
        except Exception as exc:
            return {'errors': [_('The Finkok service failed to cancel with the following error: %s', str(exc))]}

        # Preserve native acceptance/error handling, including missing Folios.
        code = message = None
        if 'Folios' in response and response.Folios:
            if 'EstatusUUID' in response.Folios.Folio[0]:
                status = response.Folios.Folio[0].EstatusUUID
                if status not in ('201', '202'):
                    code, message = status, _('Cancelling got an error')
        elif 'CodEstatus' in response:
            code, message = response.CodEstatus, _('Cancelling got an error')
        else:
            message = _('A delay of 2 hours has to be respected before to cancel')
        errors = []
        if code:
            errors.append(_('Code : %s', code))
        if message:
            errors.append(_('Message : %s', message))
        if errors:
            return {'errors': errors}
        if 'Acuse' in response:
            self._ick_store_pac_receipt(response.Acuse, uuid, company)
        return {}

    @api.model
    def _solfact_cancel(self, cfdi_values, credentials, uuid, cancel_reason, cancel_uuid=None):
        company = cfdi_values['root_company']
        certificate = cfdi_values['certificate'].with_context(bin_size=False)
        host = 'testing.solucionfactible.com' if company.l10n_mx_edi_pac_test_env else 'solucionfactible.com'
        try:
            client = Client('https://%s/ws/services/Cancelacion?wsdl' % host, timeout=20)
            key = certificate.private_key_id
            password = key.password or ''
            private_key = serialization.load_pem_private_key(base64.b64decode(key.pem_key), password=None)
            encryption = serialization.BestAvailableEncryption(password.encode()) if password else serialization.NoEncryption()
            response = client.service.cancelar(
                usuario=credentials['username'], password=credentials['password'], rfcEmisor=company.vat,
                uuids=['%s|%s|%s' % (uuid, cancel_reason, cancel_uuid or '')],
                derCertCSD=certificate._get_der_certificate_bytes(formatting='raw'),
                derKeyCSD=private_key.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, encryption),
                contrasenaCSD=password,
            )
        except Exception as exc:
            return {'errors': [_('The Solucion Factible service failed to cancel with the following error: %s', str(exc))]}
        if response.status != 200:
            return {'errors': [_('The Solucion Factible service failed to cancel with the following error: %s', response.mensaje)]}
        content = response.acuseSat if 'acuseSat' in response else None
        try:
            raw = content.encode('utf-8') if isinstance(content, str) else content
            if raw and not raw.lstrip().startswith(b'<'):
                raw = base64.b64decode(b''.join(raw.split()), validate=True)
            receipt = parse_receipt(raw, uuid, company.vat, allow_test=company.l10n_mx_edi_pac_test_env)
        except (ValueError, TypeError, binascii.Error):
            return {'errors': [_('Solución Factible procesó la solicitud sin un acuse válido. Consulte su estado antes de repetir la cancelación.')]}
        matching = [folio for folio in receipt['folios'] if folio['uuid'].upper() == uuid.upper()]
        if not matching or any(folio['status'] not in ('201', '202') for folio in matching):
            return {'errors': [_('Solución Factible no aceptó la cancelación: %s',
                                 '; '.join(folio['status_description'] for folio in matching))]}
        self._ick_store_pac_receipt(raw, uuid, company)
        return {}
