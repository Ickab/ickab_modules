import base64
from contextlib import ExitStack, contextmanager
from pathlib import Path
from lxml import etree
from unittest.mock import Mock, patch

from odoo.tests import tagged
from odoo.exceptions import AccessError, UserError
from odoo.tools.zeep.client import SerialProxy
from odoo.addons.l10n_mx_edi.tests.common import TestMxEdiCommon
from ..receipt import parse_receipt


@tagged('post_install', '-at_install')
class TestCancelReceipt(TestMxEdiCommon):
    def setUp(self):
        super().setUp()
        self.env.company.write({'l10n_mx_edi_pac': 'finkok'})

    @contextmanager
    def _native_sign(self, test_provider=False):
        def sign(document, credentials, cfdi):
            tree = etree.fromstring(cfdi)
            self.assertTrue(tree.get('Sello'))
            self.uuid += 1
            ns = 'http://www.sat.gob.mx/cfd/4'
            complement = tree.find('{%s}Complemento' % ns)
            if complement is None:
                complement = etree.SubElement(tree, '{%s}Complemento' % ns)
            etree.SubElement(complement, '{http://www.sat.gob.mx/TimbreFiscalDigital}TimbreFiscalDigital', {
                'Version': '1.1', 'UUID': '00000000-0000-0000-0000-%012d' % self.uuid,
                'FechaTimbrado': '2017-01-01T12:00:00', 'NoCertificadoSAT': '00001000000403258748',
                'RfcProvCertif': 'SPR190613I52' if test_provider else 'AAA010101AAA',
                'SelloCFD': tree.get('Sello'), 'SelloSAT': 'TEST',
            })
            return {'cfdi_str': etree.tostring(tree)}
        with self.with_mocked_pac_method('_finkok_sign', sign):
            yield

    @contextmanager
    def _native_cancel_response(self, raw):
        with patch('odoo.addons.ick_report_xml_sat_cancel.models.pac_receipt.Client') as client:
            client.return_value.service.cancel.return_value = SerialProxy(
                Folios=SerialProxy(Folio=[SerialProxy(EstatusUUID='201')]), Acuse=raw.decode())
            yield client.return_value.service.cancel

    def _receipt(self, uuid, rfc=None):
        return ('''<Acuse xmlns="http://cancelacfd.sat.gob.mx" Fecha="2026-10-19T22:20:42" RfcEmisor="%s">
          <Folios><UUID>%s</UUID><EstatusUUID>201</EstatusUUID></Folios>
          <Signature xmlns="http://www.w3.org/2000/09/xmldsig#"><SignatureValue>SELLO-DE-PRUEBA</SignatureValue>
          <KeyInfo><KeyName>000000000000</KeyName></KeyInfo></Signature></Acuse>''' % (
            rfc or self.env.company.vat, uuid)).encode()

    def test_receipt_parser_rejects_wrong_identity_and_unsafe_xml(self):
        raw = self._receipt('UUID')
        result = parse_receipt(raw, 'UUID', self.env.company.vat)
        self.assertEqual(result['date'], '2026-10-19T22:20:42')
        self.assertEqual(result['folios'][0]['status'], '201')
        self.assertFalse(result['folios'][0]['reason'])
        for bad in (b'<Comprobante/>', b'broken', b'<!DOCTYPE Acuse [<!ENTITY x SYSTEM "file:///etc/passwd">]><Acuse>&x;</Acuse>', self._receipt('OTHER'), self._receipt('UUID', 'OTHER')):
            with self.assertRaises(ValueError):
                parse_receipt(bad, 'UUID', self.env.company.vat)
        with self.assertRaises(ValueError):
            parse_receipt(self._receipt('FACTURA DE PRUEBA'), 'UUID', self.env.company.vat)
        result = parse_receipt(self._receipt('FACTURA DE PRUEBA'), 'UUID', self.env.company.vat, True)
        self.assertTrue(result['test'])
        self.assertEqual(result['folios'][0]['uuid'], 'FACTURA DE PRUEBA')

    def test_multiple_folios_and_xml_attributes(self):
        result = parse_receipt(b'<Acuse Fecha="F" RfcEmisor="RFC"><Folios UUID="FIRST" EstatusUUID="201" Motivo="01" FolioSustitucion="NEW"/><Folios UUID="SECOND" EstatusUUID="202"/></Acuse>', 'FIRST', 'RFC')
        self.assertEqual(len(result['folios']), 2)
        self.assertEqual(result['folios'][0]['replacement'], 'NEW')
        self.assertFalse(result['signature'])

    def test_native_cancel_pdf_and_xml_do_not_call_pac_or_change_original(self):
        with self.mx_external_setup(self.frozen_today), self._native_sign():
            for kind in ('out_invoice', 'out_refund', 'payment'):
                invoice = self._create_invoice(move_type='out_refund' if kind == 'out_refund' else 'out_invoice')
                invoice._l10n_mx_edi_cfdi_invoice_try_send()
                record = self._create_payment(invoice) if kind == 'payment' else invoice
                if kind == 'payment':
                    record.move_id._l10n_mx_edi_cfdi_payment_try_send()
                    source = record.l10n_mx_edi_payment_document_ids.filtered(lambda d: d.state == 'payment_sent')
                else:
                    source = invoice.l10n_mx_edi_invoice_document_ids.filtered(lambda d: d.state == 'invoice_sent')
                original = source.attachment_id
                raw = self._receipt(source.attachment_uuid)
                with self._native_cancel_response(raw) as pac:
                    if kind == 'payment':
                        record.move_id._l10n_mx_edi_cfdi_invoice_try_cancel_payment(source)
                        cancel = record.l10n_mx_edi_payment_document_ids.filtered(lambda d: d.state == 'payment_cancel')
                    else:
                        invoice._l10n_mx_edi_cfdi_invoice_try_cancel(source, '02')
                        cancel = invoice.l10n_mx_edi_invoice_document_ids.filtered(lambda d: d.state == 'invoice_cancel')
                    self.assertEqual(pac.call_count, 1)
                    pac.reset_mock()
                    self.assertTrue(cancel.ick_cancel_receipt_available)
                    values = cancel._ick_cancel_receipt_values()
                    self.assertEqual(values['attachment'].raw, raw)
                    self.assertEqual(cancel.attachment_id, original)
                    self.assertEqual(source.attachment_id, original)
                    self.assertIn('/web/content/', cancel.action_ick_download_cancel_receipt()['url'])
                    self.assertEqual(cancel.action_ick_print_cancel_receipt()['type'], 'ir.actions.report')
                    action = self.env.ref('ick_report_xml_sat_cancel.action_cancel_receipt')
                    html, _ = action._render_qweb_html(action.report_name, cancel.ids)
                    self.assertIn(b'SELLO-DE-PRUEBA', html)
                    self.assertNotIn(b'ACUSE DE PRUEBA', html)
                    if kind == 'out_invoice':
                        # force_report_rendering exercises wkhtmltopdf in test mode too.
                        pdf, _ = action.with_context(force_report_rendering=True)._render_qweb_pdf(action.report_name, cancel.ids)
                        self.assertTrue(pdf.startswith(b'%PDF'))
                        Path('/tmp/ick_cancel_receipt_preview.pdf').write_bytes(pdf)
                    pac.assert_not_called()
                    with self.assertRaises(UserError):
                        source.action_ick_print_cancel_receipt()
                    other = self.env['res.company'].create({'name': 'Unrelated report company ' + kind})
                    with self.assertRaises(AccessError):
                        cancel.with_context(allowed_company_ids=other.ids)._ick_cancel_receipt_values()

    def test_historical_test_receipt_keeps_xml_values_after_environment_change(self):
        with self.mx_external_setup(self.frozen_today), self._native_sign(test_provider=True):
            invoice = self._create_invoice()
            invoice._l10n_mx_edi_cfdi_invoice_try_send()
            source = invoice.l10n_mx_edi_invoice_document_ids.filtered(lambda d: d.state == 'invoice_sent')
            raw = self._receipt('FACTURA DE PRUEBA').replace(b'2026-10-19T22:20:42', b'2021-01-01T00:00:00')
            with self._native_cancel_response(raw):
                invoice._l10n_mx_edi_cfdi_invoice_try_cancel(source, '02')
            cancel = invoice.l10n_mx_edi_invoice_document_ids.filtered(lambda d: d.state == 'invoice_cancel')
            self.env.company.l10n_mx_edi_pac_test_env = False
            values = cancel._ick_cancel_receipt_values()
            self.assertTrue(values['test'])
            self.assertEqual(values['date'], '2021-01-01T00:00:00')
            self.assertEqual(values['folios'][0]['uuid'], 'FACTURA DE PRUEBA')
            html, _ = self.env.ref('ick_report_xml_sat_cancel.action_cancel_receipt')._render_qweb_html(
                'ick_report_xml_sat_cancel.cancel_receipt', cancel.ids)
            self.assertIn('Cancelación Simulada'.encode(), html)
            self.assertIn(b'01/01/2021 00:00:00', html)

    def test_three_native_pacs_preserve_receipt_in_native_cancellation(self):
        with self.mx_external_setup(self.frozen_today):
            for pac in ('finkok', 'solfact', 'sw'):
                for kind in ('out_invoice', 'out_refund', 'payment'):
                    with self.subTest(pac=pac, document=kind):
                        self.env.company.l10n_mx_edi_pac = 'finkok'
                        self.env.company.l10n_mx_edi_pac_test_env = True
                        with self._native_sign():
                            invoice = self._create_invoice(move_type='out_refund' if kind == 'out_refund' else 'out_invoice')
                            invoice._l10n_mx_edi_cfdi_invoice_try_send()
                            record = self._create_payment(invoice) if kind == 'payment' else invoice
                            if kind == 'payment':
                                record.move_id._l10n_mx_edi_cfdi_payment_try_send()
                                source = record.l10n_mx_edi_payment_document_ids.filtered(lambda d: d.state == 'payment_sent')
                            else:
                                source = invoice.l10n_mx_edi_invoice_document_ids.filtered(lambda d: d.state == 'invoice_sent')
                        original = source.attachment_id.raw
                        uuid = source.attachment_uuid
                        xml = self._receipt(uuid).replace(b'<Acuse ', b'<CancelaCFDResult ').replace(b'</Acuse>', b'</CancelaCFDResult>')
                        raw = (b'<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body>'
                               b'<CancelaCFDResponse xmlns="http://cancelacfd.sat.gob.mx">' + xml
                               + b'</CancelaCFDResponse></s:Body></s:Envelope>')
                        self.env.company.write({'l10n_mx_edi_pac': pac,
                                                'l10n_mx_edi_pac_username': 'contract-test',
                                                'l10n_mx_edi_pac_password': 'contract-test'})
                        with ExitStack() as stack:
                            client = stack.enter_context(patch('odoo.addons.ick_report_xml_sat_cancel.models.pac_receipt.Client'))
                            client.return_value.service.cancel.return_value = SerialProxy(
                                Folios=SerialProxy(Folio=[SerialProxy(EstatusUUID='201')]), Acuse=raw.decode())
                            client.return_value.service.cancelar.return_value = SerialProxy(
                                status=200, mensaje='OK', acuseSat=base64.b64encode(raw).decode())
                            post = stack.enter_context(patch('odoo.addons.l10n_mx_edi.models.l10n_mx_edi_document.requests.post', return_value=Mock(
                                json=lambda: {'status': 'success', 'data': {'acuse': raw.decode(), 'uuid': {uuid: '201'}}},
                            )))
                            stack.enter_context(patch.object(type(source), '_document_get_sw_token', return_value={'token': 'contract-test'}))
                            if kind == 'payment':
                                record.move_id._l10n_mx_edi_cfdi_invoice_try_cancel_payment(source)
                                cancel = record.l10n_mx_edi_payment_document_ids.filtered(lambda d: d.state == 'payment_cancel')
                            else:
                                invoice._l10n_mx_edi_cfdi_invoice_try_cancel(source, '02')
                                cancel = invoice.l10n_mx_edi_invoice_document_ids.filtered(lambda d: d.state == 'invoice_cancel')
                            self.assertTrue(cancel, (pac, kind))
                            self.assertEqual(record.l10n_mx_edi_cfdi_state, 'cancel')
                            if pac == 'finkok':
                                client.return_value.service.cancel.assert_called_once()
                                self.assertEqual(client.return_value.type_factory.return_value.UUID.return_value.Motivo, '02')
                            elif pac == 'solfact':
                                client.return_value.service.cancelar.assert_called_once()
                                kwargs = client.return_value.service.cancelar.call_args.kwargs
                                self.assertEqual(kwargs['uuids'], [uuid + '|02|'])
                                self.assertEqual(kwargs['rfcEmisor'], self.env.company.vat)
                                self.assertIn('Cancelacion?wsdl', client.call_args.args[0])
                            else:
                                post.assert_called_once()
                            values = cancel._ick_cancel_receipt_values()
                            self.assertEqual(values['attachment'].raw, raw)
                            self.assertEqual(values['signature'], 'SELLO-DE-PRUEBA')
                            self.assertEqual(values['serial'], '000000000000')
                            self.assertEqual(source.attachment_id.raw, original)
                            self.assertTrue(values['test'])
                            self.env.company.l10n_mx_edi_pac_test_env = False
                            self.assertTrue(cancel._ick_cancel_receipt_values()['test'])
                            html, _ = self.env.ref('ick_report_xml_sat_cancel.action_cancel_receipt')._render_qweb_html(
                                'ick_report_xml_sat_cancel.cancel_receipt', cancel.ids)
                            self.assertIn(b'SELLO-DE-PRUEBA', html)
                            self.assertIn(uuid.encode(), html)
                            # Printing cannot repeat the cancellation call.
                            self.assertEqual(client.return_value.service.cancel.call_count, int(pac == 'finkok'))
                            self.assertEqual(client.return_value.service.cancelar.call_count, int(pac == 'solfact'))
                            self.assertEqual(post.call_count, int(pac == 'sw'))

    def test_solfact_rejects_unsuccessful_uuid_and_missing_receipt(self):
        documents = self.env['l10n_mx_edi.document']
        values = {'root_company': self.env.company, 'certificate': self.certificate}
        credentials = {'username': 'contract-test', 'password': 'contract-test'}
        for content in (None, self._receipt('UUID').replace(b'201', b'205'), self._receipt('OTHER')):
            response = SerialProxy(status=200, mensaje='OK', acuseSat=base64.b64encode(content).decode() if content else None)
            with patch('odoo.addons.ick_report_xml_sat_cancel.models.pac_receipt.Client') as client:
                client.return_value.service.cancelar.return_value = response
                result = documents._solfact_cancel(values, credentials, 'UUID', '03')
                self.assertTrue(result.get('errors'))
                client.return_value.service.cancelar.assert_called_once()

    def test_module_uses_supplied_icon(self):
        module = self.env['ir.module.module'].search([('name', '=', 'ick_report_xml_sat_cancel')])
        self.assertEqual(module.icon, '/ick_report_xml_sat_cancel/static/src/img/icon.png')
        self.assertTrue(module.icon_image)
