"""Standalone business checks: run this file with the Odoo project's Python."""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('cancel_receipt_labels', Path(__file__).parents[1] / 'receipt.py')
receipt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(receipt)


class TestReceiptLabels(unittest.TestCase):
    def test_native_pac_soap_response_preserves_signed_values(self):
        for namespace in ('http://schemas.xmlsoap.org/soap/envelope/', 'http://www.w3.org/2003/05/soap-envelope'):
            xml = ('<s:Envelope xmlns:s="%s"><s:Body><CancelaCFDResponse xmlns="http://cancelacfd.sat.gob.mx">'
                   '<CancelaCFDResult Fecha="2026-07-27T11:51:50" RfcEmisor="RFC">'
                   '<Folios><UUID>UUID</UUID><EstatusUUID>201</EstatusUUID></Folios>'
                   '<Signature xmlns="http://www.w3.org/2000/09/xmldsig#"><SignatureValue>REAL-SEAL</SignatureValue>'
                   '<KeyInfo><KeyName>REAL-KEY</KeyName></KeyInfo></Signature>'
                   '</CancelaCFDResult></CancelaCFDResponse></s:Body></s:Envelope>' % namespace).encode()
            values = receipt.parse_receipt(xml, 'UUID', 'RFC')
            self.assertEqual(values['signature'], 'REAL-SEAL')
            self.assertEqual(values['serial'], 'REAL-KEY')
            self.assertEqual(values['date'], '2026-07-27T11:51:50')
            self.assertEqual(values['folios'][0]['status_description'], 'Solicitud de cancelación recibida')
            with self.assertRaises(ValueError):
                receipt.parse_receipt(xml, 'OTHER', 'RFC')
            with self.assertRaises(ValueError):
                receipt.parse_receipt(xml, 'UUID', 'OTHER')

    def test_reject_ambiguous_or_fake_soap_wrappers(self):
        samples = (
            b'<Envelope><Body><CancelaCFDResponse><CancelaCFDResult/></CancelaCFDResponse></Body></Envelope>',
            b'<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><CancelaCFDResponse><CancelaCFDResult/><CancelaCFDResult/></CancelaCFDResponse></s:Body></s:Envelope>',
        )
        for xml in samples:
            with self.assertRaises(ValueError):
                receipt.parse_receipt(xml, 'UUID', 'RFC')

    def parse(self, status='201', reason='01', date='2026-07-27T11:51:50'):
        xml = ('<Acuse Fecha="%s" RfcEmisor="RFC"><Folios UUID="UUID" EstatusUUID="%s" Motivo="%s" FolioSustitucion="REPLACEMENT"/></Acuse>' % (date, status, reason)).encode()
        return receipt.parse_receipt(xml, 'UUID', 'RFC')

    def test_receipt_does_not_confuse_received_with_already_cancelled(self):
        self.assertEqual(self.parse()['folios'][0]['status_description'], 'Solicitud de cancelación recibida')
        self.assertEqual(self.parse('202')['folios'][0]['status_description'], 'UUID Previamente cancelado')
        self.assertNotIn('cancelado', self.parse()['folios'][0]['status_description'].lower())

    def test_unknown_or_absent_codes_do_not_claim_success(self):
        self.assertEqual(self.parse('999')['folios'][0]['status_description'], 'Código no reconocido: 999')
        self.assertEqual(self.parse('')['folios'][0]['status_description'], 'No informado en el XML')
        self.assertEqual(self.parse(reason='')['folios'][0]['reason_description'], 'No informado en el XML')
        self.assertEqual(self.parse(reason='99')['folios'][0]['reason_description'], '99')

    def test_sample_reason_replacement_and_date_preserve_xml_data(self):
        result = self.parse()
        self.assertEqual(result['date'], '2026-07-27T11:51:50')
        self.assertEqual(result['date_display'], '27/07/2026 11:51:50')
        self.assertEqual(result['folios'][0]['reason_description'], '01 - Comprobante emitido con errores con relación')
        self.assertEqual(result['folios'][0]['replacement'], 'REPLACEMENT')

    def test_date_display_preserves_fraction_and_explicit_timezone(self):
        self.assertEqual(self.parse(date='2026-07-27T11:51:50.125-06:00')['date_display'], '27/07/2026 11:51:50.125 -06:00')

    def test_rejected_uuid_is_never_described_as_cancelled(self):
        result = self.parse('203')['folios'][0]['status_description']
        self.assertEqual(result, 'UUID No encontrado o no corresponde al emisor')
        self.assertNotIn('cancelado', result.lower())

    def test_missing_xml_reason_uses_same_registered_request(self):
        parsed = self.parse(reason='')
        result = receipt.complete_registered_data(parsed, 'UUID', '03', '30001000000500003442')
        self.assertEqual(result['folios'][0]['reason_description'], '03 - No se llevó a cabo la operación')
        self.assertEqual(result['folios'][0]['reason_source'], 'request')
        self.assertEqual(result['issuer_certificate_serial'], '30001000000500003442')
        self.assertEqual(result['folios'][0]['reason'], '')
        self.assertEqual(parsed['folios'][0]['reason_description'], 'No informado en el XML')

    def test_xml_reason_has_priority_over_request(self):
        result = receipt.complete_registered_data(self.parse(reason='01'), 'UUID', '03', 'CSD')
        self.assertEqual(result['folios'][0]['reason_description'], '01 - Comprobante emitido con errores con relación')
        self.assertEqual(result['folios'][0]['reason_source'], 'receipt')

    def test_request_reason_does_not_fill_foreign_folios(self):
        parsed = self.parse(reason='')
        parsed['folios'].append(dict(parsed['folios'][0], uuid='FOREIGN'))
        result = receipt.complete_registered_data(parsed, 'UUID', '03')
        self.assertEqual(result['folios'][0]['reason_source'], 'request')
        self.assertEqual(result['folios'][1]['reason_source'], '')
        self.assertEqual(result['folios'][1]['reason_description'], 'No informado en el XML')

    def test_test_receipt_uses_saved_reason_without_replacing_pac_signature(self):
        parsed = self.parse(reason='')
        parsed.update(test=True, signature='CCCC', serial='000000000000')
        parsed['folios'][0]['uuid'] = 'FACTURA DE PRUEBA'
        result = receipt.complete_registered_data(parsed, 'UUID', '03', '30001000000500003442')
        self.assertEqual(result['folios'][0]['reason_source'], 'request')
        self.assertEqual(result['signature'], 'CCCC')
        self.assertEqual(result['serial'], '000000000000')
        self.assertNotEqual(result['serial'], result['issuer_certificate_serial'])

    def test_test_placeholder_displays_original_uuid_without_changing_receipt(self):
        parsed = self.parse(reason='')
        parsed['test'] = True
        parsed['folios'][0]['uuid'] = 'FACTURA DE PRUEBA'
        result = receipt.complete_registered_data(parsed, '9ac15420-ee3a-4ee0-a90e-f26fda2beafe', '03')
        self.assertEqual(result['folios'][0]['uuid_display'], '9ac15420-ee3a-4ee0-a90e-f26fda2beafe')
        self.assertEqual(result['folios'][0]['uuid'], 'FACTURA DE PRUEBA')
        self.assertEqual(result['folios'][0]['uuid_source'], 'document')
        self.assertEqual(parsed['folios'][0]['uuid'], 'FACTURA DE PRUEBA')

    def test_production_folio_is_never_replaced_by_display_fallback(self):
        result = receipt.complete_registered_data(self.parse(), 'OTHER', '03')
        self.assertEqual(result['folios'][0]['uuid_display'], 'UUID')
        self.assertEqual(result['folios'][0]['uuid_source'], 'receipt')

    def test_test_placeholder_without_known_uuid_is_not_invented(self):
        parsed = self.parse()
        parsed['test'] = True
        parsed['folios'][0]['uuid'] = 'FACTURA DE PRUEBA'
        result = receipt.complete_registered_data(parsed, '')
        self.assertEqual(result['folios'][0]['uuid_display'], 'FACTURA DE PRUEBA')


if __name__ == '__main__':
    unittest.main()
