# Acuse XML de cancelación CFDI · Odoo 18

Módulo compartido: `/opt/ickab/extra-addons/extras/18/ick_report_xml_sat_cancel`.
Depende únicamente de la localización nativa `l10n_mx_edi`. No requiere `cdfi_invoice` para usar los tres PAC nativos. Para ICKAB/ITADMIN se instala además `cdfi_invoice`, como adaptador opcional del PAC. El mismo reporte admite Quadrum/Finkok, Solución Factible, SW e ITADMIN. Conserva el motor nativo de cancelación; los adaptadores preservan el XML de respuesta. Véase [compatibilidad por PAC](PAC_COMPATIBILITY.md).

En la lista CFDI de la factura, nota de crédito o pago, las filas de cancelación con un acuse guardado muestran **Acuse PDF**. El botón Descargar nativo conserva el XML original del comprobante. No se agrega una pestaña fiscal paralela.

El PDF reproduce fecha, RFC emisor, folios, códigos de estado, motivo y sustitución si están en el acuse, SignatureValue y KeyName. Lo que no está en el XML se indica como no informado. El motivo y los estados registrados por Odoo se presentan aparte, con su origen explícito. Los códigos del acuse se reproducen sin convertir una solicitud recibida en una cancelación definitiva. No verifica criptográficamente la firma ni genera un documento gubernamental original.

La descarga y la impresión no consultan ningún PAC ni SAT, no timbran, no cancelan y no modifican estados contables. Se valida acceso al asiento, compañía habilitada, UUID y RFC emisor del comprobante original; no se usa sudo. El parser admite Acuse y CancelaCFDResult, también dentro de una respuesta SOAP SAT única. Rechaza DTD, entidades externas, archivos excesivos, XML malformado y folios de otro documento. Conserva varios folios y la huella SHA-256 del archivo utilizado.

El acuse de prueba de ITADMIN puede contener `FACTURA DE PRUEBA` y fechas fijas. El XML de prueba se conserva intacto. El reporte identifica la simulación y muestra el UUID registrado del comprobante cuando el acuse utiliza el marcador genérico; mantiene sin cambios la fecha y la firma de la respuesta. Este formato solo queda disponible cuando el proveedor devuelve un XML de acuse. Si la solicitud no incluye acuse, se conserva el flujo nativo sin fabricar uno.

## Flujo

1. Odoo genera la solicitud de cancelación nativa, incluyendo motivo y UUID sustituto cuando corresponde.
2. El adaptador usa el PAC seleccionado: Quadrum/Finkok, Solución Factible, SW o ITADMIN. ITADMIN usa el servidor configurado y RFC sin contraseña PAC. Los tres PAC nativos conservan su configuración de credenciales.
3. Guarda el acuse sobre el documento enviado, sin reemplazar su `attachment_id` original. También conserva el acuse de una solicitud pendiente si el proveedor lo entrega.
4. Los callbacks nativos registran la solicitud en producción; la consulta SAT nativa determina su confirmación y aplica las reglas contables. En pruebas Odoo puede completar una cancelación simulada sin que exista en el SAT. Una respuesta pendiente en pruebas se mantiene como error pendiente para impedir ese cierre simulado prematuro.
5. El módulo localiza el acuse del mismo origen fiscal para imprimir o descargar. No modifica las decisiones de cancelación nativas.

## Instalación y validación

Instalar este módulo sobre `l10n_mx_edi` en cada base que lo necesite. Instalar `cdfi_invoice` únicamente si se utilizará ICKAB/ITADMIN, usando las rutas configuradas y deteniendo antes el servicio de esa instancia. No se crean copias por cliente. Mantener desactivada la tarea de consulta de saldo según la decisión de ICKAB.

La independencia se verificó en una base temporal: 7 pruebas del reporte con `cdfi_invoice` sin instalar; 31 pruebas del adaptador al añadir ICKAB y sus módulos relacionados; y 8 pruebas de coexistencia con ambos componentes instalados. Estas últimas comprueban los tres PAC nativos y la conservación e impresión del acuse ITADMIN para factura, nota de crédito y pago. Las respuestas PAC son simuladas; no se enviaron cancelaciones reales. Pasaron también las 14 pruebas independientes del parser. Evidencia: `../../.homologacion/ick_cancel_report_independent_tests.json`.

Pruebas Odoo aisladas: parser con namespaces/atributos y varios folios; rechazo de identidad y XML inseguros; factura, nota de crédito y complemento de pago; PDF real con wkhtmltopdf; descarga sin llamadas PAC; acceso entre compañías; solicitud pendiente de producción y confirmación SAT; independencia de `modo_prueba` y consulta SAT.

Instalación verificada en ICKAB el 19/10/2026 (20/10 UTC): 27 pruebas conjuntas aprobadas; sin alteración de las facturas revisadas, XML originales, inventario ni alertas. Las otras instancias requieren su instalación individual.

## Presentación del acuse

Los estatus se describen usando el catálogo EstatusUUID del SAT, Anexo 29 RMF 2026 VI.3. El código 201 se presenta como Solicitud de cancelación recibida y 202 como UUID Previamente cancelado. Los códigos desconocidos conservan su valor sin inferir éxito. Los motivos presentes en el XML se muestran con clave y descripción; los ausentes se indican expresamente. La fecha se presenta como día/mes/año y se conserva la hora, precisión y zona explícita del XML.

El encabezado incluye Hacienda (`static/src/img/logo_sat.png`, archivo proporcionado por el usuario) y SAT (`static/src/img/sat.svg`), incrustados localmente. Se mantienen Referencias de registro y Estado del proceso sin etiquetas Odoo en el PDF. Se retiraron el pie técnico de archivo/huella y los textos explicativos inferiores. El aviso de acuse de prueba se conserva.

Verificación independiente del parser: ejecutar `tests/test_receipt_labels.py` con el Python de la instancia.

## Datos registrados y certificado del emisor

Si el motivo no viene en el acuse, se completa con `cancellation_reason` del mismo documento de cancelación. El motivo del XML tiene prioridad. La información registrada no se aplica a otros UUID que puedan venir en un acuse con varios folios. El XML y su valor original se mantienen intactos; `reason_source` distingue el acuse de la solicitud registrada.

El número del CSD del emisor se obtiene de `NoCertificado` en el CFDI original. No se toma el certificado vigente de la configuración, porque puede haberse renovado después de la emisión. Este dato se identifica como CSD del emisor (CFDI), no como prueba de cuál certificado usó el PAC en la cancelación.

El identificador de firma (`KeyName`) y el sello (`SignatureValue`) del acuse se mantienen separados. El CSD del emisor no sustituye el sello del SAT, y al imprimir no se firma ni se consulta ningún servicio externo. Los valores de prueba del PAC se conservan e identifican como tales.

El script `tests/test_receipt_labels.py` incluye comprobaciones de estatus, fechas, correspondencia de datos registrados, conservación del XML, envolturas SOAP y separación de certificados y sellos.

El botón adicional Acuse XML se retiró de facturas y pagos a solicitud del usuario. Se conserva Descargar nativo y el archivo de acuse guardado; el cambio de presentación no elimina documentos ni adjuntos.

## Presentación de cancelaciones simuladas

La leyenda visible se limita a Cancelación Simulada. El Folio Fiscal de la tabla usa el UUID del comprobante registrado únicamente cuando existe un solo folio genérico FACTURA DE PRUEBA en un acuse simulado. La clave original del XML permanece en `uuid`; la presentación y procedencia se registran aparte en `uuid_display` y `uuid_source`. Los folios reales y los acuses de producción no se reemplazan.

El sello se identifica como sello de la respuesta de cancelación y conserva su contenido; no se sustituye por el sello del emisor ni por el del timbre original. Se retiró Motivo registrado del apartado inferior porque ya está en la tabla. El estado de referencia de una cancelación simulada se presenta como Cancelación Simulada, conservando intacto el estado nativo.

Se validaron doce casos del parser/presentación y el PDF real. La auditoría de ICKAB no encontró errores locales de RFC, certificado o credenciales. INV/2026/00079 ya estaba cancelada en prueba y su acuse guardado contenía valores de muestra. La auditoría del transporte utilizó una respuesta simulada; no reenvió cancelaciones al PAC.

## Icono del módulo

La clave `icon` del manifiesto apunta directamente al archivo proporcionado `static/src/img/icon.png`. No se duplica ni se mueve el archivo. Se muestra en la ficha del módulo; los logotipos del encabezado del acuse siguen siendo Hacienda y SAT.

## Validación aplicada el 20/10/2026

Se actualizaron `cdfi_invoice` y `ick_report_xml_sat_cancel` en ICKAB con el servicio detenido y respaldo previo. Pasaron 36 pruebas Odoo con los módulos dependientes y 14 pruebas independientes del parser. Los contratos de los tres PAC nativos se comprobaron con respuestas simuladas para factura, nota de crédito y pago; también se mantuvieron las pruebas ITADMIN. No se enviaron cancelaciones reales.

La recuperación de INV/2026/00079 se verificó con el motor PDF nativo dentro de una transacción revertida: sin proforma, con datos fiscales y marca de cancelación, conservando estados, UUID y XML. Se descartó ese adjunto de comprobación para que la primera impresión con el servicio activo use sus recursos completos. Inventario, productos, configuración y XML permanecieron iguales; la tarea diaria de saldo siguió inactiva. Tras iniciar el servicio, acceso, icono original y QR nativo respondieron HTTP 200.

Evidencia local: `../../.homologacion/ickab_pdf_recovery_result.json`, `../../.homologacion/ick_pdf_cancel_preflight.json` y `../../.homologacion/ick_pdf_shared_catalog_audit.json`. Solo se actualizó la base de ICKAB; las otras instancias conservan su estado de instalación.
