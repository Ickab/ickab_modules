"""Read cancellation receipts without inventing values absent from the XML."""
from copy import deepcopy
from datetime import datetime
from hashlib import sha256
from lxml import etree


# SAT, Anexo 29 RMF 2026, VI.3: EstatusUUID, not accounting/SAT-query states.
# https://www.sat.gob.mx/minisitio/NormatividadRMFyRGCE/documentos2026/rmf/anexos/Anexo_29_RMF2026-09012026.pdf
STATUS_LABELS = {
    '201': 'Solicitud de cancelación recibida',
    '202': 'UUID Previamente cancelado',
    '203': 'UUID No encontrado o no corresponde al emisor',
    '204': 'UUID No aplicable para cancelación',
    '205': 'UUID No existe',
    '206': 'UUID No corresponde a un CFDI del Sector Primario',
    '207': 'No se especificó el motivo de cancelación o el motivo no es válido',
    '208': 'Folio de sustitución inválido',
    '209': 'Folio de sustitución no requerido',
    '210': 'La fecha de solicitud de cancelación es mayor a la fecha de declaración',
    '211': 'La fecha de solicitud de cancelación rebasa el límite para una factura global',
    '212': 'Relación no válida o inexistente',
    '1201': 'Solicitud de cancelación recibida',
    '1202': 'UUID Previamente cancelado',
    '1203': 'No encontrado o no corresponde al emisor',
    '1205': 'UUID No existe',
}
REASON_LABELS = {
    '01': 'Comprobante emitido con errores con relación',
    '02': 'Comprobante emitido con errores sin relación',
    '03': 'No se llevó a cabo la operación',
    '04': 'Operación nominativa relacionada en una factura global',
}


def date_label(value):
    try:
        date = datetime.fromisoformat(value)
    except ValueError:
        return value
    text = date.strftime('%d/%m/%Y %H:%M:%S')
    if date.microsecond:
        text += ('.%06d' % date.microsecond).rstrip('0')
    offset = date.strftime('%z')
    if offset:
        text += ' ' + offset[:3] + ':' + offset[3:]
    return text


def parse_receipt(raw, expected_uuid, expected_rfc, allow_test=False):
    if not raw or len(raw) > 5 * 1024 * 1024:
        raise ValueError('El acuse está vacío o excede el tamaño permitido.')
    try:
        root = etree.fromstring(raw, etree.XMLParser(resolve_entities=False, no_network=True, load_dtd=False))
    except (etree.XMLSyntaxError, ValueError) as exc:
        raise ValueError('El acuse no contiene un XML válido.') from exc
    if root.getroottree().docinfo.doctype:
        raise ValueError('El XML no es un acuse de cancelación válido.')
    # ITADMIN/SW can return Acuse directly; Finkok and Solución Factible
    # also return the SAT CancelaCFDResult inside a SOAP envelope.
    name = etree.QName(root).localname
    if name == 'Envelope' and etree.QName(root).namespace in (
            'http://schemas.xmlsoap.org/soap/envelope/', 'http://www.w3.org/2003/05/soap-envelope'):
        results = root.xpath('./*[local-name()="Body"]/*[local-name()="CancelaCFDResponse"]/*[local-name()="CancelaCFDResult"]')
        if len(results) != 1:
            raise ValueError('El XML no contiene una respuesta SAT de cancelación única.')
        root = results[0]
    elif name not in ('Acuse', 'CancelaCFDResult'):
        raise ValueError('El XML no es un acuse de cancelación válido.')

    def value(node, *names):
        for key, text in node.attrib.items():
            if etree.QName(key).localname in names:
                return text.strip()
        for child in node:
            if isinstance(child.tag, str) and etree.QName(child).localname in names:
                return (child.text or '').strip()
        return ''

    folios = []
    for node in root.iter():
        if isinstance(node.tag, str) and etree.QName(node).localname in ('Folios', 'Folio'):
            uuid = value(node, 'UUID', 'Uuid')
            if uuid:
                folios.append({'uuid': uuid, 'status': value(node, 'EstatusUUID', 'EstatusCancelacion'),
                               'reason': value(node, 'Motivo'),
                               'replacement': value(node, 'FolioSustitucion', 'UUIDSustitucion')})
    if not folios:
        raise ValueError('El acuse no contiene folios fiscales.')
    test = any(folio['uuid'] == 'FACTURA DE PRUEBA' for folio in folios)
    if test and not allow_test:
        raise ValueError('Un acuse de prueba no corresponde a un comprobante de producción.')
    if not test and not any(f['uuid'].upper() == (expected_uuid or '').upper() for f in folios):
        raise ValueError('El UUID del acuse no corresponde al documento seleccionado.')
    rfc = value(root, 'RfcEmisor', 'RFCEmisor')
    if rfc and rfc.upper() != (expected_rfc or '').upper():
        raise ValueError('El RFC emisor del acuse no corresponde al comprobante original.')
    signature = serial = ''
    for node in root.iter():
        if not isinstance(node.tag, str):
            continue
        name = etree.QName(node).localname
        if name == 'SignatureValue':
            signature = (node.text or '').strip()
        elif name == 'KeyName':
            serial = (node.text or '').strip()
    for folio in folios:
        status, reason = folio['status'], folio['reason']
        folio['status_description'] = STATUS_LABELS.get(status, 'Código no reconocido: ' + status) if status else 'No informado en el XML'
        folio['reason_description'] = reason + ' - ' + REASON_LABELS[reason] if reason in REASON_LABELS else (reason or 'No informado en el XML')
    date = value(root, 'Fecha', 'FechaHora')
    return {'date': date, 'date_display': date_label(date), 'rfc': rfc, 'folios': folios,
            'signature': signature, 'serial': serial, 'test': test, 'sha256': sha256(raw).hexdigest()}


def complete_registered_data(receipt, expected_uuid, registered_reason='', issuer_certificate_serial=''):
    """Complete display data from the same request; preserve raw XML fields."""
    result = deepcopy(receipt)
    result['issuer_certificate_serial'] = issuer_certificate_serial or ''
    for folio in result['folios']:
        same_document = folio['uuid'].upper() == (expected_uuid or '').upper()
        single_test = result['test'] and len(result['folios']) == 1 and folio['uuid'] == 'FACTURA DE PRUEBA'
        folio['uuid_display'] = expected_uuid if single_test and expected_uuid else folio['uuid']
        folio['uuid_source'] = 'document' if single_test and expected_uuid else 'receipt'
        folio['reason_source'] = 'receipt' if folio['reason'] else ''
        if not folio['reason'] and registered_reason and (same_document or single_test):
            label = REASON_LABELS.get(registered_reason)
            folio['reason_description'] = registered_reason + ' - ' + label if label else registered_reason
            folio['reason_source'] = 'request'
    return result
