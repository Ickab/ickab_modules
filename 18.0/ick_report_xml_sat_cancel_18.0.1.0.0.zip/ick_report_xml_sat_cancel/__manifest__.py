{
    'name': 'ICKAB · Acuse XML de cancelación SAT',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'license': 'LGPL-3',
    'icon': '/ick_report_xml_sat_cancel/static/src/img/icon.png',
    'depends': ['l10n_mx_edi'],
    'data': ['report/cancel_receipt.xml', 'views/document_views.xml'],
    'installable': True,
}
