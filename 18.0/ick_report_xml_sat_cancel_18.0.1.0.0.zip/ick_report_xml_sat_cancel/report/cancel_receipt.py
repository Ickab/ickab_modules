import base64

from odoo import api, models
from odoo.tools import file_open
from odoo.exceptions import UserError


class CancelReceipt(models.AbstractModel):
    _name = 'report.ick_report_xml_sat_cancel.cancel_receipt'
    _description = 'Representación del acuse XML de cancelación'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['l10n_mx_edi.document'].browse(docids).exists()
        if not docs:
            raise UserError('Seleccione un documento con acuse de cancelación.')
        with file_open('ick_report_xml_sat_cancel/static/src/img/sat.svg', 'rb') as logo:
            sat_logo = 'data:image/svg+xml;base64,' + base64.b64encode(logo.read()).decode('ascii')
        with file_open('ick_report_xml_sat_cancel/static/src/img/logo_sat.png', 'rb') as logo:
            hacienda_logo = 'data:image/png;base64,' + base64.b64encode(logo.read()).decode('ascii')
        return {'hacienda_logo': hacienda_logo, 'sat_logo': sat_logo, 'doc_ids': docs.ids, 'doc_model': docs._name, 'docs': docs,
                'receipts': [doc._ick_cancel_receipt_values() for doc in docs]}
