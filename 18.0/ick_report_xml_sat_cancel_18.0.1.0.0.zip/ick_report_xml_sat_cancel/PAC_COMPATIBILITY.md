# Acuse compartido entre PAC · Odoo 18

El módulo depende solo de `l10n_mx_edi` y se instala sin `cdfi_invoice` para los tres PAC nativos. ICKAB/ITADMIN requiere además su adaptador opcional `cdfi_invoice`.

Se conserva `_cancel_api` y sus callbacks nativos para motivo, sustitución, factura, nota de crédito, pago y actualización de estados. La impresión usa un único reporte QWeb y no ejecuta solicitudes fiscales.

| PAC configurado | Respuesta conservada | Transporte |
| --- | --- | --- |
| Quadrum/Finkok (`finkok`) | `Acuse`, XML de respuesta SOAP SAT | Misma operación y validación de códigos del adaptador Odoo 18; se añade la conservación del XML. |
| Solución Factible (`solfact`) | `acuseSat`, XML codificado en base64 | Servicio `Cancelacion`, operación `cancelar`. El servicio `Timbrado.cancelar` usado por core no devuelve el acuse completo. |
| SW (`sw`) | `data.acuse`, XML | Se conserva la respuesta de `_document_sw_call`; el adaptador nativo evalúa sus códigos. |
| ITADMIN (`it_admin`) | `factura_xml`, base64 de Acuse | Adaptador existente de `cdfi_invoice`; RFC y servidor configurados, sin contraseña PAC. |

Solución Factible usa `https://testing.solucionfactible.com/ws/services/Cancelacion?wsdl` en pruebas y `https://solucionfactible.com/ws/services/Cancelacion?wsdl` en producción. El WSDL público se inspeccionó para validar `usuario`, `password`, `rfcEmisor`, `uuids`, `derCertCSD`, `derKeyCSD`, `contrasenaCSD` y `properties`. Se exporta el certificado en DER con la utilidad nativa y la llave PKCS8 en DER con su contraseña. La cadena UUID/motivo/sustitución se envía una sola vez. No se llama primero al servicio anterior ni se reintenta una cancelación.

El XML debe corresponder al UUID y RFC esperados. En Solución Factible, un estado global 200 no sustituye la validación de EstatusUUID 201/202 del folio solicitado; una respuesta sin acuse válido se informa sin inventar una confirmación. La recepción de una solicitud no implica confirmación definitiva del SAT. La actualización de estados sigue el flujo nativo, con simulación en pruebas.

Los adjuntos se guardan como `CANCEL_<UUID>.xml` en el documento EDI de origen y no reemplazan el CFDI. Se evita duplicar contenido idéntico. Los acuses capturados de los PAC nativos guardan el indicador del ambiente de prueba en el adjunto para conservar su presentación al cambiar posteriormente de ambiente. El XML, el sello y el identificador de firma se conservan intactos. No se fabrican acuses faltantes de operaciones anteriores ni se reenvían esas cancelaciones.

El lector admite `Acuse`, `CancelaCFDResult` y envolturas SOAP 1.1/1.2 que contengan una sola respuesta SAT. Los DTD, las envolturas ambiguas y las identidades ajenas se rechazan. El mismo motivo, folio, sello y certificado se presentan mediante la plantilla común.

Las pruebas de contrato simulan las respuestas de los cuatro PAC; incluyen factura, nota de crédito y pago, conservación de los XML, generación del reporte y ausencia de llamadas al imprimir. No constituyen una certificación en vivo de las cuentas de los tres PAC nativos.

Fuentes primarias consultadas:

- [Finkok: solicitud y respuesta SOAP](https://support.finkok.com/support/solutions/articles/31000157096-envolturas-soap-request-y-response).
- [Solución Factible: Cancelacion.cancelar](https://solucionfactible.com/sfic/capitulos/timbrado/ws-cancelacion-metodos/cancelar.jsp).
- [Solución Factible: limitación de Timbrado.cancelar](https://gateway.solucionfactible.com/sfic/capitulos/timbrado/ws-timbrado-cancelar-en.jsp).
- [SW: formas de obtener el acuse](https://developers.sw.com.mx/wp-content/uploads/2025/03/TC_M3_T4_formas_de_obtener_un_acuse_de_cancelacion.pdf).
