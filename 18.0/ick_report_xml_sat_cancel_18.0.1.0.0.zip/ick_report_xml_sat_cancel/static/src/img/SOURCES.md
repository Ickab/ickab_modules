# Logotipo SAT

Autor: Servicio de Administración Tributaria (México).
Recurso sin modificaciones: `sat.svg`.
Fuente del archivo: https://commons.wikimedia.org/wiki/File:Logo_del_SAT.svg
Descarga: https://upload.wikimedia.org/wikipedia/commons/a/ad/Logo_del_SAT.svg
La ficha identifica como fuente original http://omawww.sat.gob.mx/CIAT2016/Paginas/images/sat.png .

Se conserva la proporción original. El recurso se incrusta en el PDF como data URI, por lo que su impresión no depende de acceso a internet ni de un servicio HTTP de imágenes. La representación identifica expresamente los acuses de prueba y conserva el XML original como fuente.

Hacienda: archivo `logo_sat.png` proporcionado por el usuario en esta carpeta, integrado sin modificaciones y conservando proporciones.
