from odoo import api, SUPERUSER_ID
from odoo.addons.cdfi_invoice.migration import migrate_legacy


def migrate(cr, version):
    migrate_legacy(api.Environment(cr, SUPERUSER_ID, {}))
