"""One-time transfer from retained legacy columns; no remote fiscal operations."""
import json
import logging
from lxml import etree

from odoo import Command, fields, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


def migrate_legacy(env):
    # Columns are intentionally retained even after replacing fields with aliases.
    env.cr.execute("""SELECT c.id, c.nombre_fiscal, c.modo_prueba, r.code
                      FROM res_company c LEFT JOIN catalogo_regimen_fiscal r ON r.id=c.regimen_fiscal_id
                      WHERE c.company_cfdi""")
    for company_id, name, test_env, regime in env.cr.fetchall():
        company = env['res.company'].browse(company_id)
        values = {'l10n_mx_edi_pac': 'it_admin', 'l10n_mx_edi_pac_test_env': bool(test_env)}
        if name:
            values['name'] = name
        if regime:
            values['l10n_mx_edi_fiscal_regime'] = regime
        company.write(values)
        if company.archivo_cer and company.archivo_key:
            certificates = company.sudo().l10n_mx_edi_certificate_ids.with_context(bin_size=False)
            if not certificates.filtered(lambda cert: cert.content == company.archivo_cer):
                key = env['certificate.key'].sudo().create({
                    'name': 'ITADMIN CSD', 'company_id': company.id,
                    'content': company.archivo_key, 'password': company.contrasena,
                })
                cert = env['certificate.certificate'].sudo().create({
                    'name': 'ITADMIN CSD', 'company_id': company.id,
                    'content': company.archivo_cer, 'private_key_id': key.id,
                })
                if key.loading_error or cert.loading_error:
                    raise UserError(_('El CSD de la compañía %s no se puede importar al modelo nativo.', company.id))

    env.cr.execute("""SELECT p.id, r.code, u.code FROM res_partner p
                      LEFT JOIN catalogo_regimen_fiscal r ON r.id=p.regimen_fiscal_id
                      LEFT JOIN catalogo_uso_cfdi u ON u.id=p.uso_cfdi_id
                      WHERE p.regimen_fiscal_id IS NOT NULL OR p.uso_cfdi_id IS NOT NULL""")
    for partner_id, regime, usage in env.cr.fetchall():
        values = {}
        if regime:
            values['l10n_mx_edi_fiscal_regime'] = regime
        if usage:
            values['l10n_mx_edi_usage'] = usage
        env['res.partner'].browse(partner_id).write(values)

    codes = env['product.unspsc.code'].with_context(active_test=False)
    env.cr.execute("""SELECT id,clave_producto FROM product_template
                      WHERE clave_producto IS NOT NULL""")
    for product_id, product_code in env.cr.fetchall():
        product = env['product.template'].browse(product_id)
        values = {}
        if product_code and not product.unspsc_code_id:
            native_code = codes.search([('code', '=', product_code), ('applies_to', '=', 'product')], limit=1)
            if not native_code:
                # Explicit client instruction: retain their exact fiscal codes,
                # including codes absent from the bundled Odoo catalogue.
                # Do not infer a different classification from a product name.
                native_code = codes.create({
                    'code': product_code,
                    'name': env._('Clave proporcionada por el cliente: %s', product_code),
                    'applies_to': 'product', 'active': True,
                })
            values['unspsc_code_id'] = native_code.id
        product.write(values)

    env.cr.execute("SELECT id,impuesto,tipo_factor FROM account_tax WHERE impuesto IS NOT NULL OR tipo_factor IS NOT NULL")
    types = {'001': 'isr', '002': 'iva', '003': 'ieps', '004': 'local'}
    for tax_id, tax_type, factor in env.cr.fetchall():
        values = {}
        if tax_type:
            values['l10n_mx_tax_type'] = types[tax_type]
        if factor:
            values['l10n_mx_factor_type'] = factor
        env['account.tax'].browse(tax_id).write(values)

    env.cr.execute("""SELECT m.id,u.code,f.code,m.tipo_relacion,m.uuid_relacionado,m.fecha_factura
                      FROM account_move m LEFT JOIN catalogo_uso_cfdi u ON u.id=m.uso_cfdi_id
                      LEFT JOIN catalogo_forma_pago f ON f.id=m.forma_pago_id
                      WHERE m.uso_cfdi_id IS NOT NULL OR m.forma_pago_id IS NOT NULL OR m.folio_fiscal IS NOT NULL""")
    for move_id, usage, method, relation, origin, date in env.cr.fetchall():
        values = {}
        if usage:
            values['l10n_mx_edi_usage'] = usage
        if method:
            values['l10n_mx_edi_payment_method_id'] = env['l10n_mx_edi.payment.method'].search([('code', '=', method)], limit=1).id
        if relation and origin:
            values['l10n_mx_edi_cfdi_origin'] = '%s|%s' % (relation, origin)
        if date:
            values['l10n_mx_edi_post_time'] = date
        env['account.move'].browse(move_id).write(values)

    env.cr.execute("""SELECT p.id,f.code,p.tipo_relacion,p.uuid_relacionado,p.date_payment
                      FROM account_payment p LEFT JOIN catalogo_forma_pago f ON f.id=p.forma_pago_id
                      WHERE p.forma_pago_id IS NOT NULL OR p.folio_fiscal IS NOT NULL""")
    for payment_id, method, relation, origin, date in env.cr.fetchall():
        payment = env['account.payment'].browse(payment_id)
        values = {}
        if method:
            values['l10n_mx_edi_payment_method_id'] = env['l10n_mx_edi.payment.method'].search([('code', '=', method)], limit=1).id
        if relation and origin:
            values['l10n_mx_edi_cfdi_origin'] = '%s|%s' % (relation, origin)
        if date:
            values['l10n_mx_edi_post_time'] = date
        if payment.move_id:
            payment.move_id.write(values)

    missing_xml_records = []
    for model, status_field, success, sent_state, cancel_state in (
        ('account.move', 'estado_factura', 'factura_correcta', 'invoice_sent', 'invoice_cancel'),
        ('account.payment', 'estado_pago', 'pago_correcto', 'payment_sent', 'payment_cancel'),
    ):
        for record in env[model].search([('folio_fiscal', '!=', False)]):
            move = record if model == 'account.move' else record.move_id
            if not move:
                raise UserError(_('El pago %s tiene UUID y carece de asiento nativo.', record.id))
            existing = env['l10n_mx_edi.document'].search([
                ('move_id', '=', move.id), ('attachment_uuid', '=', record.folio_fiscal),
                ('state', 'in', [sent_state, cancel_state, 'invoice_cancel_requested']),
            ], limit=1)
            if existing:
                continue
            attachments = env['ir.attachment'].search([
                ('res_model', '=', model), ('res_id', '=', record.id),
                ('name', 'not ilike', 'CANCEL_%'),
            ])
            attachment = env['ir.attachment']
            for candidate in attachments:
                try:
                    node = etree.fromstring(candidate.raw, etree.XMLParser(resolve_entities=False, no_network=True))
                    stamp = node.find('{http://www.sat.gob.mx/cfd/4}Complemento/{http://www.sat.gob.mx/TimbreFiscalDigital}TimbreFiscalDigital')
                    if stamp is not None and stamp.get('UUID', '').upper() == record.folio_fiscal.upper():
                        attachment = candidate
                        break
                except (etree.XMLSyntaxError, ValueError, TypeError):
                    continue
            if not attachment:
                # Missing historical files must not roll back unrelated product
                # fiscal data. Keep the original UUID and the resend guard;
                # never invent a native EDI document without its signed XML.
                missing_xml_records.append({'model': model, 'id': record.id})
                continue
            status = record[status_field]
            state = cancel_state if status == 'factura_cancelada' else sent_state
            if status == 'solicitud_cancelar' and model == 'account.move':
                state = 'invoice_cancel_requested'
            env['l10n_mx_edi.document'].create({
                'move_id': move.id, 'attachment_id': attachment.id, 'state': state,
                'datetime': move.l10n_mx_edi_post_time or attachment.create_date or fields.Datetime.now(),
                'sat_state': 'cancelled' if status == 'factura_cancelada' else 'not_defined',
                'invoice_ids': [Command.set(move.ids if model == 'account.move' else record.reconciled_invoice_ids.ids)],
            })
    env['ir.config_parameter'].sudo().set_param(
        'cdfi_invoice.migration_missing_xml', json.dumps(missing_xml_records))
    if missing_xml_records:
        _logger.warning('CFDI migration: %s historical documents retain their UUID pending XML recovery; product fiscal codes were migrated.', len(missing_xml_records))
