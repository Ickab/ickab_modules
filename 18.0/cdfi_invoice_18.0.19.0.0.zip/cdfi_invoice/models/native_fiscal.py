"""Compatibility names backed by the fiscal records owned by Odoo 18.

The old catalog models remain addressable for imports and downstream modules.
They are lookup adapters, not a second source of fiscal configuration.
"""
import base64
import binascii
import math
from dateutil import parser

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


def catalog(record, model, code, key='code'):
    return record.env[model].search([(key, '=', code)], limit=1) if code else False


class Company(models.Model):
    _inherit = 'res.company'

    l10n_mx_edi_pac = fields.Selection(
        selection_add=[('it_admin', 'ICKAB')], default='it_admin',
        ondelete={'it_admin': 'set null'})
    nombre_fiscal = fields.Char(related='name', readonly=False, store=False)
    modo_prueba = fields.Boolean(related='l10n_mx_edi_pac_test_env', readonly=False, store=False)
    regimen_fiscal_id = fields.Many2one(
        compute='_compute_legacy_regime', inverse='_inverse_legacy_regime', store=False)

    @api.depends('l10n_mx_edi_fiscal_regime')
    def _compute_legacy_regime(self):
        for company in self:
            company.regimen_fiscal_id = catalog(company, 'catalogo.regimen.fiscal', company.l10n_mx_edi_fiscal_regime)

    def _inverse_legacy_regime(self):
        for company in self:
            company.l10n_mx_edi_fiscal_regime = company.regimen_fiscal_id.code

    def get_saldo(self):
        self.ensure_one()
        documents = self.env['l10n_mx_edi.document']
        credentials = documents._get_it_admin_credentials(self)
        if credentials.get('errors'):
            raise UserError('\n'.join(credentials['errors']))
        result = documents._itadmin_request(credentials['sign_url'].rsplit('/', 1)[0] + '/saldo', {
            'rfc': self.vat, 'api_key': self.proveedor_timbrado,
            'modo_prueba': self.l10n_mx_edi_pac_test_env,
        })
        if result.get('errors'):
            raise UserError('\n'.join(result['errors']))
        if result.get('estado_saldo') == 'problemas_saldo' or not result.get('saldo'):
            raise UserError(result.get('problemas_message') or _('ITADMIN no confirmó el saldo de timbres.'))
        try:
            balance = float(base64.b64decode(result['saldo'], validate=True))
            expiry = parser.parse(result['vigencia']).date() if result.get('vigencia') else False
            if not math.isfinite(balance) or balance < 0:
                raise ValueError('Invalid balance')
        except (ValueError, TypeError, binascii.Error, OverflowError):
            raise UserError(_('ITADMIN devolvió un saldo de timbres inválido.'))
        self.write({'saldo_timbres': balance, 'fecha_timbres': expiry})

    @api.constrains('saldo_alarma')
    def _check_itadmin_alert_minimum(self):
        if any(not math.isfinite(company.saldo_alarma) or company.saldo_alarma < 0 for company in self):
            raise ValidationError(_('El mínimo de timbres para alertas debe ser un número mayor o igual a cero.'))


class Settings(models.TransientModel):
    _inherit = 'res.config.settings'

    itadmin_server = fields.Selection(
        related='company_id.proveedor_timbrado', readonly=False, string='Servidor',
        help='Servidor utilizado para timbrar, cancelar y consultar saldo. El cambio de servidor es manual.')
    itadmin_balance = fields.Float(related='company_id.saldo_timbres', string='Timbres disponibles')
    itadmin_balance_expiry = fields.Date(related='company_id.fecha_timbres', string='Vigencia de timbres')
    itadmin_balance_alarm = fields.Float(
        related='company_id.saldo_alarma', readonly=False, string='Mínimo de timbres para alerta',
        help='Se envía una alerta cuando el saldo consultado es menor que este mínimo.')
    itadmin_alarm_email = fields.Char(
        related='company_id.correo_alarma', readonly=False, string='Correos para alertas',
        help='Destinatarios de las alertas de esta compañía, separados por comas.')

    def action_itadmin_balance(self):
        self.ensure_one()
        self.company_id.get_saldo()


class Partner(models.Model):
    _inherit = 'res.partner'

    regimen_fiscal_id = fields.Many2one(
        compute='_compute_legacy_fiscal', inverse='_inverse_legacy_regime', store=False)
    uso_cfdi_id = fields.Many2one(
        compute='_compute_legacy_fiscal', inverse='_inverse_legacy_usage', store=False)

    @api.depends('l10n_mx_edi_fiscal_regime', 'l10n_mx_edi_usage')
    def _compute_legacy_fiscal(self):
        for partner in self:
            partner.regimen_fiscal_id = catalog(partner, 'catalogo.regimen.fiscal', partner.l10n_mx_edi_fiscal_regime)
            partner.uso_cfdi_id = catalog(partner, 'catalogo.uso.cfdi', partner.l10n_mx_edi_usage)

    def _inverse_legacy_regime(self):
        for partner in self:
            partner.l10n_mx_edi_fiscal_regime = partner.regimen_fiscal_id.code

    def _inverse_legacy_usage(self):
        for partner in self:
            partner.l10n_mx_edi_usage = partner.uso_cfdi_id.code


class Product(models.Model):
    _inherit = 'product.template'

    clave_producto = fields.Char(
        compute='_compute_legacy_sat', inverse='_inverse_legacy_product',
        search='_search_legacy_product', store=False)
    cat_unidad_medida = fields.Many2one(
        compute='_compute_legacy_sat', inverse='_inverse_legacy_uom', store=False)

    @api.depends('unspsc_code_id.code', 'uom_id.unspsc_code_id.code')
    def _compute_legacy_sat(self):
        for product in self:
            product.clave_producto = product.unspsc_code_id.code
            unit_code = product.uom_id.unspsc_code_id.code
            product.cat_unidad_medida = catalog(product, 'catalogo.unidad.medida', unit_code, 'clave')

    def _search_legacy_product(self, operator, value):
        return [('unspsc_code_id.code', operator, value)]

    def _inverse_legacy_product(self):
        for product in self:
            code = product.clave_producto
            native = product.env['product.unspsc.code'].with_context(active_test=False).search([
                ('code', '=', code), ('applies_to', '=', 'product')], limit=1) if code else False
            if code and not native:
                product.check_access('write')
                # The native catalogue is read-only for ordinary users.
                # This bridge can only add the exact client-supplied code;
                # it never edits or replaces any existing catalogue entry.
                native = product.env['product.unspsc.code'].sudo().create({
                    'code': code, 'name': _('Clave proporcionada por el cliente: %s', code),
                    'applies_to': 'product', 'active': True,
                })
            product.unspsc_code_id = native

    def _inverse_legacy_uom(self):
        for product in self:
            code = product.cat_unidad_medida.clave
            if code != product.uom_id.unspsc_code_id.code:
                raise ValidationError(_('La unidad SAT se obtiene de la unidad de medida nativa del producto. Seleccione allí la unidad correspondiente.'))


class Move(models.Model):
    _inherit = 'account.move'

    uso_cfdi_id = fields.Many2one(compute='_compute_legacy_invoice_fiscal', inverse='_inverse_legacy_usage', store=False)
    forma_pago_id = fields.Many2one(compute='_compute_legacy_invoice_fiscal', inverse='_inverse_legacy_method', store=False)
    methodo_pago = fields.Selection(selection=None, related='l10n_mx_edi_payment_policy', readonly=True, store=False)

    @api.depends('l10n_mx_edi_usage', 'l10n_mx_edi_payment_method_id.code')
    def _compute_legacy_invoice_fiscal(self):
        for move in self:
            move.uso_cfdi_id = catalog(move, 'catalogo.uso.cfdi', move.l10n_mx_edi_usage)
            move.forma_pago_id = catalog(move, 'catalogo.forma.pago', move.l10n_mx_edi_payment_method_id.code)

    def _inverse_legacy_usage(self):
        for move in self:
            move.l10n_mx_edi_usage = move.uso_cfdi_id.code

    def _inverse_legacy_method(self):
        for move in self:
            move.l10n_mx_edi_payment_method_id = catalog(move, 'l10n_mx_edi.payment.method', move.forma_pago_id.code)

    def action_ickab_update_issue_time(self):
        self.ensure_one()
        self.check_access('write')
        self.env['res.company']._with_locked_records(self)
        if self.state != 'posted' or self.move_type not in ('out_invoice', 'out_refund') or not self.l10n_mx_edi_is_cfdi_needed:
            raise UserError(_('Actualice la fecha de emisión desde una factura o nota de crédito mexicana confirmada.'))
        if self.folio_fiscal or self.l10n_mx_edi_cfdi_uuid or self.l10n_mx_edi_invoice_document_ids.filtered('attachment_uuid'):
            raise UserError(_('No se puede actualizar la fecha de emisión de un documento que ya tiene un UUID.'))
        documents = self.env['l10n_mx_edi.document']
        values = documents._get_company_cfdi_values(self.company_id)
        if values.get('errors'):
            raise UserError('\n'.join(values['errors']))
        # Odoo stores this particular field as local emission wall time and
        # writes it directly to XML. Do not convert it to UTC or use the old
        # invoice date, as _get_min_of_now_and_document_date would do.
        issue_time = documents._get_datetime_now_with_mx_timezone(values, journal=self.journal_id).replace(
            tzinfo=None, microsecond=0,
        )
        self.l10n_mx_edi_post_time = issue_time
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Fecha de emisión actualizada'),
                'message': _('La próxima emisión del CFDI usará %s.', fields.Datetime.to_string(issue_time)),
                'type': 'success',
                'next': {'type': 'ir.actions.client', 'tag': 'reload'},
            },
        }

    def action_cfdi_generate(self):
        for move in self:
            if move.folio_fiscal and not move.l10n_mx_edi_cfdi_uuid:
                raise UserError(_('Migre el XML histórico al documento nativo antes de emitir nuevamente.'))
            if move.tipo_comprobante == 'T':
                raise UserError(_('Utilice el flujo nativo de traslado y su localización correspondiente.'))
            move._l10n_mx_edi_cfdi_invoice_try_send()
        return True

    def _l10n_mx_edi_cfdi_invoice_try_send(self):
        self.ensure_one()
        if self.folio_fiscal and not self.l10n_mx_edi_cfdi_uuid:
            raise UserError(_('El documento tiene un UUID histórico sin migrar; recupere su XML antes de emitirlo.'))
        return super()._l10n_mx_edi_cfdi_invoice_try_send()

    def _l10n_mx_edi_cfdi_payment_try_send(self, force_cfdi=False):
        self.ensure_one()
        if self.origin_payment_id.folio_fiscal and not self.l10n_mx_edi_cfdi_uuid:
            raise UserError(_('El pago tiene un UUID histórico sin migrar; recupere su XML antes de emitirlo.'))
        return super()._l10n_mx_edi_cfdi_payment_try_send(force_cfdi=force_cfdi)

    def action_cfdi_cancel(self):
        self.ensure_one()
        return self.button_request_cancel()

    def action_cfdi_rechazada(self):
        self.l10n_mx_edi_cfdi_try_sat()
        return True

    def liberar_cfdi(self):
        raise UserError(_('Utilice el seguimiento y las acciones del documento CFDI nativo.'))

    def _l10n_mx_edi_cfdi_invoice_document_sent(self, cfdi_filename, cfdi_str):
        document = super()._l10n_mx_edi_cfdi_invoice_document_sent(cfdi_filename, cfdi_str)
        self._set_data_from_xml(cfdi_str)
        self.write({'estado_factura': 'factura_correcta', 'factura_cfdi': True, 'proceso_timbrado': False})
        return document

    def _l10n_mx_edi_cfdi_payment_document_sent(self, invoices, cfdi_filename, cfdi_str):
        document = super()._l10n_mx_edi_cfdi_payment_document_sent(invoices, cfdi_filename, cfdi_str)
        if self.origin_payment_id:
            self.origin_payment_id._set_data_from_xml(cfdi_str)
            self.origin_payment_id.estado_pago = 'pago_correcto'
        return document

    def check_cancel_status_by_cron(self):
        moves = self.search([('estado_factura', '=', 'solicitud_cancelar')])
        moves.l10n_mx_edi_cfdi_try_sat()
        return True

    def _l10n_mx_edi_cfdi_move_update_sat_state(self, document, sat_state, error=None):
        result = super()._l10n_mx_edi_cfdi_move_update_sat_state(document, sat_state, error=error)
        if sat_state == 'cancelled':
            if self.is_invoice():
                self.estado_factura = 'factura_cancelada'
            elif self.origin_payment_id:
                self.origin_payment_id.estado_pago = 'factura_cancelada'
        return result


class Payment(models.Model):
    _inherit = 'account.payment'

    forma_pago_id = fields.Many2one(compute='_compute_legacy_payment_method', inverse='_inverse_legacy_payment_method', store=False)

    @api.depends('l10n_mx_edi_payment_method_id.code')
    def _compute_legacy_payment_method(self):
        for payment in self:
            payment.forma_pago_id = catalog(payment, 'catalogo.forma.pago', payment.l10n_mx_edi_payment_method_id.code)

    def _inverse_legacy_payment_method(self):
        for payment in self:
            payment.l10n_mx_edi_payment_method_id = catalog(payment, 'l10n_mx_edi.payment.method', payment.forma_pago_id.code)

    def complete_payment(self):
        for payment in self:
            if payment.folio_fiscal and not payment.l10n_mx_edi_cfdi_uuid:
                raise UserError(_('Migre el XML histórico del pago antes de emitir nuevamente.'))
            payment.l10n_mx_edi_cfdi_payment_force_try_send()
        return True

    def action_cfdi_cancel(self):
        self.ensure_one()
        document = self.l10n_mx_edi_payment_document_ids.filtered(
            lambda doc: doc.state == 'payment_sent' and doc.attachment_uuid == self.l10n_mx_edi_cfdi_uuid)[:1]
        if not document:
            raise UserError(_('No hay un documento nativo de pago timbrado para cancelar.'))
        return document.action_cancel()


class Tax(models.Model):
    _inherit = 'account.tax'

    tipo_factor = fields.Selection(selection=None, related='l10n_mx_factor_type', readonly=False, store=False)
    impuesto = fields.Selection(compute='_compute_legacy_tax', inverse='_inverse_legacy_tax', store=False)

    @api.depends('l10n_mx_tax_type')
    def _compute_legacy_tax(self):
        codes = {'isr': '001', 'iva': '002', 'ieps': '003', 'local': '004'}
        for tax in self:
            tax.impuesto = codes.get(tax.l10n_mx_tax_type)

    def _inverse_legacy_tax(self):
        codes = {'001': 'isr', '002': 'iva', '003': 'ieps', '004': 'local'}
        for tax in self:
            tax.l10n_mx_tax_type = codes.get(tax.impuesto)
