# -*- coding: utf-8 -*-

import base64
import json
import logging
import math
from datetime import datetime

import pytz
from lxml import etree
from io import BytesIO
import qrcode
from odoo import api, fields, models, _
from . import amount_to_text_es_MX

_logger = logging.getLogger(__name__)


class AccountRegisterPayment(models.TransientModel):
    _inherit = 'account.payment.register'

    def validate_complete_payment(self):
        for rec in self:
            payments = rec._create_payments()
            if len(payments) > 1:
                return
            else:
                return {
                    'name': _('Payments'),
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'account.payment',
                    'view_id': False,
                    'type': 'ir.actions.act_window',
                    'res_id': payments.id,
                }

    def _create_payment_vals_from_wizard(self, batch_result):
        res = super(AccountRegisterPayment, self)._create_payment_vals_from_wizard(batch_result)

        timezone = self._context.get('tz')
        if not timezone:
            timezone = self.env.user.partner_id.tz or 'America/Mexico_City'
        local = pytz.timezone(timezone)
        naive_from = self.payment_date
        res.update({'fecha_pago': datetime(self.payment_date.year, self.payment_date.month, self.payment_date.day, 16,
                                           0, tzinfo=local).strftime("%Y-%m-%d %H:%M:%S")})
        return res

    company_cfdi = fields.Boolean(related="company_id.company_cfdi", store=True)


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    forma_pago_id = fields.Many2one('catalogo.forma.pago', string='Forma de pago')
    forma_de_pago = fields.Char(related="forma_pago_id.code", string="Forma pago")

    methodo_pago = fields.Selection(
        selection=[('PUE', _('Pago en una sola exhibición')),
                   ('PPD', _('Pago en parcialidades o diferido')), ],
        string=_('Método de pago'),
    )
    # no_de_pago = fields.Integer("No. de pago", readonly=True)
    # saldo_pendiente = fields.Float("Saldo pendiente", readonly=True)
    # monto_pagar = fields.Float("Monto a pagar", compute='_compute_monto_pagar')
    # saldo_restante = fields.Float("Saldo restante", readonly=True)
    fecha_pago = fields.Datetime("Fecha de pago")
    date_payment = fields.Datetime("Fecha de CFDI", copy=False)
    cuenta_emisor = fields.Many2one('res.partner.bank', string=_('Cuenta del emisor'))
    banco_emisor = fields.Char("Banco del emisor", related='cuenta_emisor.bank_name', readonly=True)
    rfc_banco_emisor = fields.Char(_("RFC banco emisor"), related='cuenta_emisor.bank_bic', readonly=True)
    numero_operacion = fields.Char(_("Número de operación"))
    banco_receptor = fields.Char(_("Banco receptor"), compute='_compute_banco_receptor')
    cuenta_beneficiario = fields.Char(_("Cuenta beneficiario"), compute='_compute_banco_receptor')
    rfc_banco_receptor = fields.Char(_("RFC banco receptor"), compute='_compute_banco_receptor')
    estado_pago = fields.Selection(
        selection=[('pago_no_enviado', 'REP no generado'), ('pago_correcto', 'REP correcto'),
                   ('problemas_factura', 'Problemas con el pago'), ('solicitud_cancelar', 'Cancelación en proceso'),
                   ('cancelar_rechazo', 'Cancelación rechazada'), ('factura_cancelada', 'REP cancelado'), ],
        string=_('Estado CFDI'),
        default='pago_no_enviado',
        readonly=True,
        copy=False,
    )
    tipo_relacion = fields.Selection(
        selection=[('04', 'Sustitución de los CFDI previos'), ],
        string=_('Tipo relación'),
    )
    uuid_relacionado = fields.Char(string=_('CFDI Relacionado'))
    confirmacion = fields.Char(string=_('Confirmación'))
    folio_fiscal = fields.Char(string=_('Folio Fiscal'), readonly=True, copy=False)
    numero_cetificado = fields.Char(string=_('Numero de certificado'), copy=False)
    cetificaso_sat = fields.Char(string=_('Cetificado SAT'), copy=False)
    fecha_certificacion = fields.Char(string=_('Fecha y Hora Certificación'), copy=False)
    cadena_origenal = fields.Char(string=_('Cadena Original del Complemento digital de SAT'), copy=False)
    selo_digital_cdfi = fields.Char(string=_('Sello Digital del CDFI'), copy=False)
    selo_sat = fields.Char(string=_('Sello del SAT'), copy=False)
    #   moneda = fields.Char(string=_('Moneda'))
    monedap = fields.Char(string=_('Moneda'))
    #    tipocambio = fields.Char(string=_('TipoCambio'))
    tipocambiop = fields.Char(string=_('TipoCambio'))
    #folio = fields.Char(string=_('Folio'))
    #  version = fields.Char(string=_('Version'))
    number_folio = fields.Char(string=_('Folio'), compute='_get_number_folio')
    amount_to_text = fields.Char('Amount to Text', compute='_get_amount_to_text',
                                 size=256,
                                 help='Amount of the invoice in letter')
    qr_value = fields.Char(string=_('QR Code Value'), copy=False)
    qrcode_image = fields.Binary("QRCode", copy=False)
    #    rfc_emisor = fields.Char(string=_('RFC'))
    #    name_emisor = fields.Char(string=_('Name'))
    xml_payment_link = fields.Char(string=_('XML link'), readonly=True, copy=False)
    payment_mail_ids = fields.One2many('account.payment.mail', 'payment_id', string='Payment Mails')
    iddocumento = fields.Char(string=_('iddocumento'))
    fecha_emision = fields.Char(string=_('Fecha y Hora Certificación'), copy=False)
    docto_relacionados = fields.Text("Docto relacionados", default='[]')
    cep_sello = fields.Char(string=_('cep_sello'))
    cep_numeroCertificado = fields.Char(string=_('cep_numeroCertificado'))
    cep_cadenaCDA = fields.Char(string=_('cep_cadenaCDA'))
    cep_claveSPEI = fields.Char(string=_('cep_claveSPEI'))
    retencionesp = fields.Text("traslados P", default='[]')
    trasladosp = fields.Text("retenciones P", default='[]')
    total_pago = fields.Float("Total pagado")
    partials_payment_ids = fields.One2many('facturas.pago', 'doc_id', 'Montos')
    manual_partials = fields.Boolean("Montos manuales")
    different_currency = fields.Boolean(_("Diferente moneda"), compute='_compute_different_currency')
    company_cfdi = fields.Boolean(related="company_id.company_cfdi", store=True)
    redondeo_t_base = fields.Selection(
        selection=[('01', _('Tradicional')),
                   ('02', _('Decimal')),
                   ('03', _('Techo')),
                   ('04', _('Truncar')),],
        default='01',
        string=_('Redondeo base'), 
    )
    redondeo_t_impuesto = fields.Selection(
        selection=[('01', _('Tradicional')),
                   ('02', _('Decimal')),
                   ('03', _('Techo')),
                   ('04', _('Truncar')),],
        default='01',
        string=_('Redondeo impuesto'), 
    )
    redondeo_t_total = fields.Selection(
        selection=[('01', _('Tradicional')),
                   ('02', _('Decimal')),
                   ('03', _('Techo')),
                   ('04', _('Truncar')),],
        default='01',
        string=_('Redondeo total'), 
    )

    @api.depends('name')
    def _get_number_folio(self):
        for record in self:
            if record.name:
                record.number_folio = record.name.replace('CUST.IN', '').replace('/', '')

    @api.model
    def get_docto_relacionados(self, payment):
        try:
            data = json.loads(payment.docto_relacionados)
        except Exception:
            data = []
        return data

    def _compute_different_currency(self):
        for payment in self:
            if payment.reconciled_invoice_ids:
                for invoice in payment.reconciled_invoice_ids:
                    if invoice.currency_id != payment.currency_id:
                        payment.different_currency = True
                        break
                    else:
                        payment.different_currency = False
            else:
                payment.different_currency = False

    def importar_incluir_cep(self):
        ctx = {'default_payment_id': self.id}
        return {
            'name': _('Importar factura de compra'),
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': self.env.ref('cdfi_invoice.view_import_xml_payment_in_payment_form_view').id,
            'res_model': 'import.account.payment.from.xml',
            'context': ctx,
            'type': 'ir.actions.act_window',
            'target': 'new',
        }


    # @api.onchange('date')
    # def _onchange_payment_date(self):
    #     if self.date:
    #         self.fecha_pago = datetime.combine((self.date), datetime.max.time())


    def post(self):
        res = super(AccountPayment, self).post()
        for rec in self:
            #        rec.add_resitual_amounts()
            rec._onchange_payment_date()
            rec._onchange_journal()
        return res

    @api.depends('amount')
    def _compute_monto_pagar(self):
        for record in self:
            if record.amount:
                record.monto_pagar = record.amount
            else:
                record.monto_pagar = 0

    @api.depends('journal_id')
    def _compute_banco_receptor(self):
        for record in self:
            if record.journal_id and record.journal_id.bank_id:
                record.banco_receptor = record.journal_id.bank_id.name
                record.rfc_banco_receptor = record.journal_id.bank_id.bic
            else:
                record.banco_receptor = ''
                record.rfc_banco_receptor = ''
                record.cuenta_beneficiario = ''
            if record.journal_id:
                record.cuenta_beneficiario = record.journal_id.bank_acc_number
            else:
                record.banco_receptor = ''
                record.rfc_banco_receptor = ''
                record.cuenta_beneficiario = ''

    @api.depends('amount', 'currency_id')
    def _get_amount_to_text(self):
        for record in self:
            record.amount_to_text = amount_to_text_es_MX.get_amount_to_text(record, record.amount_total, 'es_cheque',
                                                                            record.currency_id.name)

    @api.model
    def _get_amount_2_text(self, amount_total):
        return amount_to_text_es_MX.get_amount_to_text(self, amount_total, 'es_cheque', self.currency_id.name)


    def set_decimals(self, amount, precision):
        if amount is None or amount is False:
            return None
        return '%.*f' % (precision, amount)

    def roundTraditional(self, val, digits):
       if val != 0:
          return round(val + 10 ** (-len(str(val)) - 1), digits)
       else:
          return 0

    def trunc(self, val, digits):
       if val != 0:
          x = 10 ** digits
          return int(val*x)/(x)
       else:
          return 0

    def selectRoundseparate(self, val, digits, r_option):
       if r_option == '01':
           return self.roundTraditional(val, digits)
       elif r_option == '02':
           return self.set_decimals(val, digits)
       elif r_option == '03':
           return math.ceil(val*100)/100
       else:
           return self.trunc(val, digits)

    def clean_text(self, text):
        clean_text = text.replace('\n', ' ').replace('\\', ' ').replace('-', ' ').replace('/', ' ').replace('|', ' ')
        clean_text = clean_text.replace(',', ' ').replace(';', ' ').replace('>', ' ').replace('<', ' ')
        return clean_text[:1000]


    def _set_data_from_xml(self, xml_payment):
        if not xml_payment:
            return None
        NSMAP = {
            'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            'cfdi': 'http://www.sat.gob.mx/cfd/4',
            'tfd': 'http://www.sat.gob.mx/TimbreFiscalDigital',
            'pago20': 'http://www.sat.gob.mx/Pagos20',
        }
        xml_data = etree.fromstring(xml_payment)
        Complemento = xml_data.find('cfdi:Complemento', NSMAP)
        TimbreFiscalDigital = Complemento.find('tfd:TimbreFiscalDigital', NSMAP)

        self.numero_cetificado = xml_data.attrib['NoCertificado']
        self.fecha_emision = xml_data.attrib['Fecha']
        self.cetificaso_sat = TimbreFiscalDigital.attrib['NoCertificadoSAT']
        self.fecha_certificacion = TimbreFiscalDigital.attrib['FechaTimbrado']
        self.selo_digital_cdfi = TimbreFiscalDigital.attrib['SelloCFD']
        self.selo_sat = TimbreFiscalDigital.attrib['SelloSAT']
        self.folio_fiscal = TimbreFiscalDigital.attrib['UUID']
        #self.folio = xml_data.attrib['Folio']
        version = TimbreFiscalDigital.attrib['Version']
        self.cadena_origenal = '||%s|%s|%s|%s|%s||' % (version, self.folio_fiscal, self.fecha_certificacion,
                                                       self.selo_digital_cdfi, self.cetificaso_sat)

        qr_value = 'https://verificacfdi.facturaelectronica.sat.gob.mx/default.aspx?&id=%s&re=%s&rr=%s&tt=%s.%s&fe=%s' % (
        self.folio_fiscal,
        self.company_id.vat,
        self.partner_id.vat,
        '0000000000',
        '000000',
        self.selo_digital_cdfi[-8:],
        )
        self.qr_value = qr_value
        image = BytesIO()
        qrcode.make(qr_value).save(image, format='PNG')
        self.qrcode_image = base64.b64encode(image.getvalue())

    def send_payment(self):
        self.ensure_one()
        template = self.env.ref('cdfi_invoice.email_template_payment')
        compose_form = self.env.ref('mail.email_compose_message_wizard_form')
        # The native Mexican localization supplies the existing CFDI XML via
        # _process_attachments_for_template_post, independently of its name.
        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form.id, 'form')],
            'target': 'new',
            'context': {
                **self.env.context,
                'default_model': self._name,
                'default_res_ids': self.ids,
                'default_template_id': template.id,
                'default_composition_mode': 'comment',
            },
        }

    def truncate(self, number, decimals=0):
        """
        Returns a value truncated to a specific number of decimal places.
        """
        if not isinstance(decimals, int):
            raise TypeError("decimal places must be an integer.")
        elif decimals < 0:
            raise ValueError("decimal places has to be 0 or more.")
        elif decimals == 0:
            return math.trunc(number)

        factor = 10.0 ** decimals
        return math.trunc(number * factor) / factor

    def get_name(self):
        for payment in self:
            return payment.name.replace('.', '').replace('/', '_')


class AccountPaymentMail(models.Model):
    _name = "account.payment.mail"
    _inherit = ['mail.thread']
    _description = "Payment Mail"

    payment_id = fields.Many2one('account.payment', string='Payment')
    name = fields.Char(related='payment_id.name')
    xml_payment_link = fields.Char(related='payment_id.xml_payment_link')
    partner_id = fields.Many2one(related='payment_id.partner_id')
    company_id = fields.Many2one(related='payment_id.company_id')


class AccountPaymentTerm(models.Model):
    "Terminos de pago"
    _inherit = "account.payment.term"

    methodo_pago = fields.Selection(
        selection=[('PUE', _('Pago en una sola exhibición')),
                   ('PPD', _('Pago en parcialidades o diferido')), ],
        string=_('Método de pago'),
    )
    forma_pago_id = fields.Many2one('catalogo.forma.pago', string='Forma de pago')
    company_cfdi = fields.Boolean(string='Compania CFDI', compute='_get_company')

    @api.depends('company_id')
    def _get_company(self):
        for record in self:
            if record.company_id:
                record.company_cfdi = record.company_id.company_cfdi
            else:
                record.company_cfdi = True


class FacturasPago(models.Model):
    _name = "facturas.pago"
    _description = 'Facturas ligadas a pago'

    doc_id = fields.Many2one('account.payment', 'Pago ligado')
    facturas_id = fields.Many2one('account.move', string='Factura')
    parcialidad = fields.Integer("Parcialidad")
    imp_saldo_ant = fields.Float("ImpSaldoAnt")
    imp_pagado = fields.Float("ImpPagado")
    imp_saldo_insoluto = fields.Float("ImpSaldoInsoluto", compute='_compute_insoluto')
    equivalenciadr = fields.Float("EquivalenciaDR", digits=(12, 10), default=1)

    @api.depends('imp_saldo_ant', 'imp_pagado')
    def _compute_insoluto(self):
        for rec in self:
            rec.imp_saldo_insoluto = rec.imp_saldo_ant - rec.imp_pagado

    @api.onchange('facturas_id')
    def _compute_saldo_ant(self):
        for rec in self:
            if rec.facturas_id:
                rec.imp_saldo_ant = rec.facturas_id.amount_total_in_currency_signed
