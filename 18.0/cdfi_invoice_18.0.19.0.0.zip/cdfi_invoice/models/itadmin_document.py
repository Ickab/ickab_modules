"""ITADMIN PAC hooks for Odoo 18's native Mexican EDI pipeline.

Wire contract: itadmin01/l10n_mx_itadmin, branch 18.0,
l10n_mx_edi_mx_pac/models/account_edi_format.py.
No invoice/tax/payment calculations belong in this adapter.
"""
import base64
import binascii

import requests
from lxml import etree

from odoo import api, models, _
from odoo.tools.translate import LazyTranslate


_native_lt = LazyTranslate('l10n_mx_edi')


class ItadminDocument(models.Model):
    _inherit = 'l10n_mx_edi.document'

    @api.model
    def _get_company_cfdi_values(self, company):
        values = super()._get_company_cfdi_values(company)
        # ITADMIN identifies the account by RFC and does not use a PAC
        # password. Keep native company resolution and every other error.
        if values['root_company'].l10n_mx_edi_pac == 'it_admin':
            password_error = self.env._(_native_lt('No PAC credentials specified.'))
            errors = [error for error in values.get('errors', []) if error != password_error]
            if errors:
                values['errors'] = errors
            else:
                values.pop('errors', None)
        return values

    def _cancel_api(self, company, cancel_reason, on_failure, on_success):
        self.ensure_one()
        # Native Odoo calls the PAC hook on an empty model recordset. Carry
        # the source document through the native flow to retain its receipt.
        document = self.with_context(itadmin_cancel_document_id=self.id)
        return super(ItadminDocument, document)._cancel_api(
            company, cancel_reason, on_failure, on_success,
        )

    @api.model
    def _get_it_admin_credentials(self, company):
        servers = {
            'servidor': 'https://facturacion.itadmin.com.mx',
            'servidor2': 'https://facturacion2.itadmin.com.mx',
        }
        server = servers.get(company.proveedor_timbrado)
        if not company.vat or not server:
            return {'errors': [_('Configure el RFC y el servidor ITADMIN de la compañía.') ]}
        return {
            'username': company.vat,
            'modo_prueba': company.l10n_mx_edi_pac_test_env,
            'sign_url': server + '/api/invoice',
            'cancel_url': server + '/api/refund',
        }

    @api.model
    def _itadmin_request(self, url, values):
        # Never retry a stamp after a timeout: the remote result is unknown.
        # Never include requests/exceptions or complete responses in logs.
        try:
            response = requests.post(url, json=values, timeout=(10, 60))
            response.raise_for_status()
            result = response.json()
        except requests.Timeout:
            return {'errors': [_('ITADMIN no confirmó la operación a tiempo. Verifique el documento con el proveedor antes de reenviarlo.') ]}
        except (requests.RequestException, ValueError):
            return {'errors': [_('No se pudo obtener una respuesta válida de ITADMIN.') ]}
        if not isinstance(result, dict):
            return {'errors': [_('ITADMIN devolvió una respuesta inválida.') ]}
        if result.get('estado_factura') == 'problemas_factura':
            return {'errors': [result.get('problemas_message') or _('ITADMIN rechazó la operación.') ]}
        return result

    @api.model
    def _it_admin_sign(self, credentials, cfdi):
        result = self._itadmin_request(credentials['sign_url'], {
            'enterprise': {
                'rfc': credentials['username'],
                'modo_prueba': credentials['modo_prueba'],
                'xml': cfdi.decode('utf-8'),
            },
        })
        if result.get('errors'):
            return result
        if result.get('estado_factura') != 'factura_correcta' or not result.get('factura_xml'):
            return {'errors': [_('ITADMIN no devolvió un XML timbrado confirmado.') ]}
        try:
            stamped = base64.b64decode(result['factura_xml'], validate=True)
            parser = etree.XMLParser(resolve_entities=False, no_network=True)
            source = etree.fromstring(cfdi, parser)
            root = etree.fromstring(stamped, parser)
            ns = {'c': 'http://www.sat.gob.mx/cfd/4', 't': 'http://www.sat.gob.mx/TimbreFiscalDigital'}
            stamp = root.find('c:Complemento/t:TimbreFiscalDigital', ns)
            if root.tag != source.tag or stamp is None or not stamp.get('UUID'):
                raise ValueError('Missing stamp')
            # ITADMIN can return an earlier document for a repeated serie/folio.
            # Reject mismatched identity/amounts before Odoo records it as sent.
            for key in ('Serie', 'Folio', 'TipoDeComprobante', 'Moneda', 'Total', 'Fecha', 'NoCertificado', 'Sello'):
                if root.get(key, '') != source.get(key, ''):
                    raise ValueError('Document mismatch')
            if not source.get('Sello') or stamp.get('SelloCFD') != source.get('Sello'):
                raise ValueError('Seal mismatch')
            for tag in ('Emisor', 'Receptor'):
                if root.find('c:' + tag, ns).get('Rfc') != source.find('c:' + tag, ns).get('Rfc'):
                    raise ValueError('RFC mismatch')
        except (ValueError, TypeError, AttributeError, binascii.Error, etree.XMLSyntaxError):
            return {'errors': [_('El XML de ITADMIN no contiene un timbre válido para este documento. Verifique la operación con el proveedor.') ]}
        return {'cfdi_str': stamped}

    def _it_admin_cancel(self, cfdi_values, credentials, uuid, cancel_reason, cancel_uuid=None):
        company = cfdi_values['root_company']
        result = self._itadmin_request(credentials['cancel_url'], {
            'rfc': company.vat,
            'api_key': 'na',
            'uuid': uuid,
            'folio': 'na',
            'serie_factura': 'na',
            'modo_prueba': credentials['modo_prueba'],
            'certificados': {'archivo_cer': '', 'archivo_key': '', 'contrasena': ''},
            'xml': '',
            'motivo': cancel_reason,
            'foliosustitucion': cancel_uuid or '',
        })
        if result.get('errors'):
            return result
        pending = result.get('estado_factura') == 'solicitud_cancelar'
        if result.get('estado_factura') not in ('solicitud_cancelar', 'factura_cancelada'):
            return {'errors': [_('ITADMIN no confirmó la solicitud de cancelación.')]}
        if pending and not result.get('factura_xml'):
            if credentials['modo_prueba']:
                return {'errors': [_('La cancelación sigue pendiente en ITADMIN; consulte su estado antes de repetirla.')]}
            return {}
        try:
            receipt = base64.b64decode(result.get('factura_xml', ''), validate=True)
            root = etree.fromstring(receipt, etree.XMLParser(resolve_entities=False, no_network=True, load_dtd=False))
            if root.getroottree().docinfo.doctype or etree.QName(root).localname != 'Acuse':
                raise ValueError('Not a cancellation receipt')
            uuids = [str(value).strip().upper() for value in root.xpath(
                "//*[local-name()='UUID']/text() | //@UUID")]
            if uuid.upper() not in uuids and not (credentials['modo_prueba'] and 'FACTURA DE PRUEBA' in uuids):
                raise ValueError('Receipt UUID mismatch')
            issuer = root.get('RfcEmisor') or root.get('RFCEmisor')
            if issuer and issuer.upper() != company.vat.upper():
                raise ValueError('Receipt issuer mismatch')
        except (ValueError, TypeError, binascii.Error, etree.XMLSyntaxError):
            return {'errors': [_('ITADMIN devolvió un acuse de cancelación inválido para este documento.')]}
        document = self
        if not document and self.env.context.get('itadmin_cancel_document_id'):
            document = self.browse(self.env.context['itadmin_cancel_document_id']).exists()
        if document:
            document.ensure_one()
            attachments = self.env['ir.attachment']
            name = 'CANCEL_%s.xml' % uuid
            existing = attachments.search([
                ('res_model', '=', document._name), ('res_id', '=', document.id),
                ('name', '=', name),
            ])
            if not any(attachment.raw == receipt for attachment in existing):
                attachments.create({
                    'name': name,
                    'raw': receipt,
                    'res_model': document._name,
                    'res_id': document.id,
                    'mimetype': 'application/xml',
                })
        if pending and credentials['modo_prueba']:
            return {'errors': [_('La cancelación sigue pendiente en ITADMIN; consulte su estado antes de repetirla.')]}
        return {}
