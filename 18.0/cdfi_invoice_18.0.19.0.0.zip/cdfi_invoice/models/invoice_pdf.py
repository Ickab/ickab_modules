"""Recover a missing PDF through Odoo's report engine, without sending EDI."""

from odoo import _, models
from odoo.exceptions import UserError
from odoo.addons.mail.tools.discuss import Store


CFDI_TEST_DESCRIPTION = 'CFDI (prueba)'
CFDI_PRODUCTION_DESCRIPTION = 'CFDI (producción)'


class AccountMove(models.Model):
    _inherit = 'account.move'

    def _l10n_mx_edi_cfdi_invoice_document_sent(self, cfdi_filename, cfdi_str):
        document = super()._l10n_mx_edi_cfdi_invoice_document_sent(cfdi_filename, cfdi_str)
        # Native attachment metadata records the environment at issuance for
        # every PAC. Later configuration changes must not relabel this XML.
        document.attachment_id.description = (
            CFDI_TEST_DESCRIPTION if self.company_id.root_id.l10n_mx_edi_pac_test_env
            else CFDI_PRODUCTION_DESCRIPTION
        )
        return document

    def _ick_invoice_report_is_test(self):
        self.ensure_one()
        attachment = self.l10n_mx_edi_cfdi_attachment_id
        if attachment:
            values = self._l10n_mx_edi_get_extra_invoice_report_values()
            node = values.get('cfdi_node')
            if node is not None and 'SPR190613I52' in node.xpath(
                    "//*[local-name()='TimbreFiscalDigital']/@RfcProvCertif"):
                return True
            if attachment.description in (CFDI_TEST_DESCRIPTION, CFDI_PRODUCTION_DESCRIPTION):
                return attachment.description == CFDI_TEST_DESCRIPTION
        # Historical XML from another PAC may not identify its sandbox.
        return bool(self.company_id.root_id.l10n_mx_edi_pac_test_env)

    def _ick_refresh_invoice_pdf_attachments(self):
        """Refresh the current user's native attachment list, without email."""
        self.ensure_one()
        self.env.user._bus_send_store(self, {
            'attachments': Store.many(self._get_mail_thread_data_attachments()),
        }, as_thread=True)

    def _ick_has_stamped_invoice_xml(self):
        self.ensure_one()
        return (
            self.move_type in ('out_invoice', 'out_refund')
            and self.state in ('posted', 'cancel')
            and self.l10n_mx_edi_cfdi_state in ('sent', 'cancel')
            and bool(self.l10n_mx_edi_cfdi_attachment_id)
        )

    def _ick_ensure_invoice_pdf(self, force=False):
        """Restore only the native PDF attachment. Never run sending/EDI hooks.

        Access is checked before the narrowly scoped attachment creation, as in
        account.move.send. Printing does not mark the invoice as sent.
        """
        self.ensure_one()
        self.check_access('read')
        self.line_ids.check_access('read')
        if (self.invoice_pdf_report_id and not force) or not self._ick_has_stamped_invoice_xml():
            if self.invoice_pdf_report_id:
                self._ick_refresh_invoice_pdf_attachments()
            return self.invoice_pdf_report_id

        self.env['res.company']._with_locked_records(self)
        self.invalidate_recordset(['invoice_pdf_report_id', 'invoice_pdf_report_file',
                                   'state', 'l10n_mx_edi_cfdi_state',
                                   'l10n_mx_edi_cfdi_attachment_id'])
        if (self.invoice_pdf_report_id and not force) or not self._ick_has_stamped_invoice_xml():
            if self.invoice_pdf_report_id:
                self._ick_refresh_invoice_pdf_attachments()
            return self.invoice_pdf_report_id

        attachment = self.l10n_mx_edi_cfdi_attachment_id
        attachment.check_access('read')
        values = self.env['l10n_mx_edi.document']._decode_cfdi_attachment(attachment.raw)
        uuid = (values.get('uuid') or '').upper()
        issuer = (values.get('supplier_rfc') or '').upper()
        if (not uuid or not values.get('sello_sat')
                or values['sello_sat'] == 'No identificado'
                or issuer != (self.company_id.root_id.vat or '').upper()
                or uuid != (self.l10n_mx_edi_cfdi_uuid or '').upper()):
            raise UserError(_("No se puede regenerar el PDF: el XML timbrado no corresponde a esta factura."))

        # This context selects the native MX template for cancelled invoices too.
        # It affects this render only; the stored accounting/CFDI state is intact.
        invoice = self.with_company(self.company_id).with_context(
            ick_recover_invoice_pdf=True, proforma_invoice=False,
            report_pdf_no_attachment=True,
        )
        sender = invoice.env['account.move.send']
        data = {invoice: {'pdf_report': sender._get_default_pdf_report_id(invoice)}}
        sender._prepare_invoice_pdf_report(data)
        pdf_values = data[invoice]['pdf_attachment_values']
        if not pdf_values['raw'].startswith(b'%PDF-'):
            raise UserError(_("No se pudo generar un PDF válido para esta factura."))
        if self.invoice_pdf_report_id:
            # Explicit reprinting refreshes this same native attachment so
            # layout corrections appear immediately without duplicate PDFs.
            pdf = self.invoice_pdf_report_id.sudo()
            pdf.write({key: pdf_values[key] for key in ('raw', 'name', 'mimetype')})
        else:
            pdf = self.env['ir.attachment'].sudo().create(pdf_values)
        self.invalidate_recordset(['invoice_pdf_report_id', 'invoice_pdf_report_file'])
        self._ick_refresh_invoice_pdf_attachments()
        return pdf

    def _get_name_invoice_report(self):
        if self.env.context.get('ick_recover_invoice_pdf') and self._ick_has_stamped_invoice_xml():
            return 'l10n_mx_edi.report_invoice_document'
        return super()._get_name_invoice_report()

    def _get_invoice_legal_documents(self, filetype, allow_fallback=False):
        if filetype == 'pdf':
            self._ick_ensure_invoice_pdf()
        return super()._get_invoice_legal_documents(filetype, allow_fallback=allow_fallback)

    def _get_invoice_legal_documents_all(self, allow_fallback=False):
        self._ick_ensure_invoice_pdf()
        return super()._get_invoice_legal_documents_all(allow_fallback=allow_fallback)

    def action_print_pdf(self):
        self.ensure_one()
        if self._ick_has_stamped_invoice_xml():
            self._ick_ensure_invoice_pdf(force=True)
            return self.action_invoice_download_pdf()
        return super().action_print_pdf()
